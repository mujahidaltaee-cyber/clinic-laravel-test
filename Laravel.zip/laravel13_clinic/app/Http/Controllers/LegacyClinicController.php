<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class LegacyClinicController extends Controller
{
    public function handle(Request $request): Response
    {
        // The existing tested PHP/MySQL engine is mounted here so the user interface
        // and all features remain exactly the same while the project boots through Laravel 13.
        // It outputs the response directly and exits for downloads / JSON calls.
        ob_start();
        require base_path('legacy/clinic_engine.php');
        $content = ob_get_clean();

        return response($content);
    }
}
