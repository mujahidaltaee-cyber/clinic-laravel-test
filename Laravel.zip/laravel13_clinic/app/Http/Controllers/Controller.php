<?php

namespace App\Http\Controllers;

abstract class Controller
{
    // Base controller for the Laravel 13 application.
}
