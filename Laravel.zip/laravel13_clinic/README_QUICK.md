AUIB Chair Booking System - Laravel 13

1) Run composer install locally/Codespaces.
2) Upload all files including vendor/ to AwardSpace.
3) Keep .htaccess in root and public/.htaccess inside public.
4) Open /?setup=MJ04Dima to connect MySQL.
