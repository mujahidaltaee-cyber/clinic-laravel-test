<?php
session_start();
date_default_timezone_set('Asia/Baghdad');

const APP_NAME = 'Dental Clinic Reservation';
const OWNER_NAME = 'Mujahid Jabbar';
const OWNER_PASSWORD = 'MJ04Dima';
const SETUP_KEY = OWNER_PASSWORD; // setup page unlock key
const CONFIG_FILE = __DIR__ . '/data/db_config.php';

function config_exists(): bool { return file_exists(CONFIG_FILE); }

function mysql_config(): array {
    if (!config_exists()) {
        throw new Exception('MySQL is not configured yet. Open the website and complete the setup screen first.');
    }
    $cfg = require CONFIG_FILE;
    if (!is_array($cfg)) throw new Exception('Invalid MySQL configuration file.');
    return $cfg;
}

function connect_mysql(array $cfg): PDO {
    $host = $cfg['host'] ?? 'localhost';
    $port = $cfg['port'] ?? '3306';
    $name = $cfg['database'] ?? '';
    $user = $cfg['username'] ?? '';
    $pass = $cfg['password'] ?? '';
    if ($name === '' || $user === '') throw new Exception('Database name and username are required.');
    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function db(): PDO {
    static $db = null;
    if ($db) return $db;
    if (!is_dir(__DIR__ . '/data')) mkdir(__DIR__ . '/data', 0775, true);
    $db = connect_mysql(mysql_config());
    $db->exec("SET NAMES utf8mb4");
    init_db($db);
    return $db;
}

function save_mysql_config(array $cfg): void {
    if (!is_dir(__DIR__ . '/data')) mkdir(__DIR__ . '/data', 0775, true);
    $export = var_export([
        'host' => $cfg['host'],
        'port' => $cfg['port'],
        'database' => $cfg['database'],
        'username' => $cfg['username'],
        'password' => $cfg['password'],
    ], true);
    file_put_contents(CONFIG_FILE, "<?php\nreturn " . $export . ";\n");
}

function now_str(): string { return date('Y-m-d H:i:s'); }
function current_clinic_week_bounds(): array {
    $today = new DateTimeImmutable('today');
    $dayOfWeek = (int)$today->format('w'); // 0 Sunday ... 6 Saturday
    $daysSinceSaturday = ($dayOfWeek - 6 + 7) % 7;
    $start = $today->modify('-' . $daysSinceSaturday . ' days');
    $end = $start->modify('+6 days');
    return [$start, $end];
}
function valid_session(string $s): bool { return in_array($s, ['08:00','11:00','14:00'], true); }
function session_label(string $s): string { return $s === '14:00' ? '2:00' : $s; }
function session_datetime(string $date, string $session): DateTimeImmutable { return new DateTimeImmutable($date . ' ' . $session . ':00'); }
function hours_before_session(string $date, string $session, float $hours): DateTimeImmutable { return session_datetime($date, $session)->modify('-' . (int)round($hours * 60) . ' minutes'); }
function public_url(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $path = strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
    return $scheme . '://' . $host . $path;
}
function json_out(array $data): never { header('Content-Type: application/json'); echo json_encode($data); exit; }
function ensure_column(PDO $db, string $table, string $column, string $definition): void {
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) {
        throw new Exception('Invalid schema identifier.');
    }
    // AwardSpace/MySQL can reject placeholders in SHOW COLUMNS statements,
    // so the table/column names are strictly validated above and the LIKE value is quoted.
    $quotedColumn = $db->quote($column);
    $st = $db->query("SHOW COLUMNS FROM `{$table}` LIKE {$quotedColumn}");
    if ($st && $st->fetch()) return;
    $db->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
}

function mysql_backup_download(): never {
    $db = db();
    try { set_setting($db, 'last_backup_at', now_str()); } catch (Throwable $e) {}
    $filename = 'clinic-mysql-backup-' . date('Y-m-d-His') . '.sql';
    header('Content-Type: application/sql; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo "-- Dental Clinic Reservation MySQL Backup\n";
    echo "-- Generated: " . date('Y-m-d H:i:s') . "\n\n";
    echo "SET FOREIGN_KEY_CHECKS=0;\n\n";
    $tables = $db->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'")->fetchAll(PDO::FETCH_NUM);
    foreach ($tables as $row) {
        $table = $row[0];
        echo "DROP TABLE IF EXISTS `{$table}`;\n";
        $create = $db->query("SHOW CREATE TABLE `{$table}`")->fetch(PDO::FETCH_ASSOC);
        echo $create['Create Table'] . ";\n\n";
        $rows = $db->query("SELECT * FROM `{$table}`")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $r) {
            $cols = array_map(fn($c)=>'`' . str_replace('`','``',$c) . '`', array_keys($r));
            $vals = array_map(fn($v)=>$v === null ? 'NULL' : $db->quote((string)$v), array_values($r));
            echo "INSERT INTO `{$table}` (" . implode(',', $cols) . ") VALUES (" . implode(',', $vals) . ");\n";
        }
        echo "\n";
    }
    echo "SET FOREIGN_KEY_CHECKS=1;\n";
    exit;
}

function full_access_accounts(): array {
    return [
        ['name'=>'Mujahid Jabbar', 'login_id'=>'MJ-OWNER', 'password'=>OWNER_PASSWORD],
        ['name'=>'Dima Baraa', 'login_id'=>'DB-OWNER', 'password'=>OWNER_PASSWORD],
    ];
}
function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $st = db()->prepare('SELECT id, name, university_id, role, must_change_password, created_at FROM users WHERE id = ?');
    $st->execute([$_SESSION['user_id']]);
    $u = $st->fetch();
    if (!$u) return null;
    $u['id'] = (int)$u['id'];
    $u['must_change_password'] = !empty($u['must_change_password']);
    return $u;
}
function require_user(): array {
    $u = current_user();
    if (!$u) json_out(['ok'=>false, 'message'=>'Please login first.']);
    return $u;
}
function role_allowed(array $u, array $roles): bool { return in_array($u['role'], $roles, true); }

function init_db(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        university_id VARCHAR(100) NULL,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL DEFAULT 'student',
        created_at VARCHAR(19) NOT NULL,
        updated_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY users_name_unique (name),
        UNIQUE KEY users_university_id_unique (university_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS courses (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        code VARCHAR(50) NOT NULL,
        name VARCHAR(255) NOT NULL,
        session VARCHAR(5) NOT NULL DEFAULT '08:00',
        active TINYINT(1) NOT NULL DEFAULT 1,
        color VARCHAR(20) DEFAULT '#2563eb',
        created_at VARCHAR(19) NOT NULL,
        updated_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS course_chairs (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        course_id INT UNSIGNED NOT NULL,
        chair_number TINYINT UNSIGNED NOT NULL,
        created_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY course_chair_unique (course_id, chair_number),
        CONSTRAINT course_chairs_course_fk FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS course_chair_assignments (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        course_id INT UNSIGNED NOT NULL,
        assignment_date DATE NOT NULL,
        session VARCHAR(5) NOT NULL,
        chair_number TINYINT UNSIGNED NOT NULL,
        created_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY course_date_session_chair_unique (course_id, assignment_date, session, chair_number),
        UNIQUE KEY date_session_chair_unique (assignment_date, session, chair_number),
        CONSTRAINT assignments_course_fk FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS reservations (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NOT NULL,
        booking_date DATE NOT NULL,
        session VARCHAR(5) NOT NULL,
        course_id INT UNSIGNED NOT NULL,
        chair_number TINYINT UNSIGNED NOT NULL,
        operator_name VARCHAR(255) NOT NULL,
        assistant_name VARCHAR(255) NOT NULL,
        patient_name VARCHAR(255) NOT NULL,
        patient_phone VARCHAR(100) NULL,
        notes TEXT NULL,
        supervisor_name VARCHAR(255) NOT NULL,
        patient_permission TINYINT(1) NOT NULL DEFAULT 0,
        status VARCHAR(30) NOT NULL DEFAULT 'active',
        active_lock TINYINT(1) NULL DEFAULT 1,
        status_note TEXT NULL,
        created_at VARCHAR(19) NOT NULL,
        updated_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY reservation_chair_active_unique (booking_date, session, chair_number, active_lock),
        UNIQUE KEY reservation_user_session_active_unique (user_id, booking_date, session, active_lock),
        KEY reservations_course_idx (course_id),
        CONSTRAINT reservations_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        CONSTRAINT reservations_course_fk FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    ensure_column($db, 'reservations', 'patient_permission', 'TINYINT(1) NOT NULL DEFAULT 0');
    ensure_column($db, 'reservations', 'patient_phone', 'VARCHAR(100) NULL');
    ensure_column($db, 'reservations', 'notes', 'TEXT NULL');
    ensure_column($db, 'courses', 'color', "VARCHAR(20) DEFAULT '#2563eb'");

    $db->exec("CREATE TABLE IF NOT EXISTS blocked_chairs (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_date DATE NOT NULL,
        session VARCHAR(5) NOT NULL,
        chair_number TINYINT UNSIGNED NOT NULL,
        reason TEXT NULL,
        created_by INT UNSIGNED NULL,
        created_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY blocked_date_session_chair_unique (booking_date, session, chair_number),
        KEY blocked_created_by_idx (created_by)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS audit_logs (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NULL,
        reservation_id INT UNSIGNED NULL,
        action VARCHAR(80) NOT NULL,
        details TEXT NULL,
        created_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id),
        KEY audit_user_idx (user_id),
        KEY audit_reservation_idx (reservation_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS approved_students (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        university_id VARCHAR(100) NOT NULL,
        name VARCHAR(255) NOT NULL,
        allowed TINYINT(1) NOT NULL DEFAULT 1,
        created_by INT UNSIGNED NULL,
        created_at VARCHAR(19) NOT NULL,
        updated_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY approved_student_uid_unique (university_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS waiting_list (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NOT NULL,
        booking_date DATE NOT NULL,
        session VARCHAR(5) NOT NULL,
        course_id INT UNSIGNED NOT NULL,
        status VARCHAR(30) NOT NULL DEFAULT 'waiting',
        notified_at VARCHAR(19) NULL,
        created_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY waiting_user_course_unique (user_id, booking_date, session, course_id, status),
        KEY waiting_course_idx (course_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS notifications (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id),
        KEY notifications_user_idx (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS app_settings (
        setting_key VARCHAR(100) NOT NULL,
        setting_value TEXT NULL,
        updated_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (setting_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS login_attempts (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        identifier VARCHAR(255) NOT NULL,
        ip_address VARCHAR(64) NOT NULL,
        success TINYINT(1) NOT NULL DEFAULT 0,
        created_at VARCHAR(19) NOT NULL,
        PRIMARY KEY (id),
        KEY login_attempts_idx (identifier, ip_address, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    ensure_column($db, 'users', 'must_change_password', 'TINYINT(1) NOT NULL DEFAULT 0');
    ensure_column($db, 'reservations', 'permission_status', "VARCHAR(30) NOT NULL DEFAULT 'not_needed'");
    ensure_column($db, 'reservations', 'check_in_status', "VARCHAR(40) NOT NULL DEFAULT 'not_checked'");
    ensure_column($db, 'reservations', 'qr_token', 'VARCHAR(80) NULL');
    ensure_column($db, 'reservations', 'last_check_in_at', 'VARCHAR(19) NULL');

    foreach (full_access_accounts() as $acc) {
        $st = $db->prepare("SELECT id FROM users WHERE name = ? OR university_id = ? LIMIT 1");
        $st->execute([$acc['name'], $acc['login_id']]);
        $existing = $st->fetch();
        if (!$existing) {
            $st = $db->prepare("INSERT INTO users (name, university_id, password_hash, role, created_at, updated_at) VALUES (?, ?, ?, 'owner', ?, ?)");
            $st->execute([$acc['name'], $acc['login_id'], password_hash($acc['password'], PASSWORD_DEFAULT), now_str(), now_str()]);
        } else {
            $st = $db->prepare("UPDATE users SET name=?, role='owner', password_hash=?, university_id=?, updated_at=? WHERE id=?");
            $st->execute([$acc['name'], password_hash($acc['password'], PASSWORD_DEFAULT), $acc['login_id'], now_str(), (int)$existing['id']]);
        }
    }
}

function get_setting(PDO $db, string $key, string $default=''): string {
    $st = $db->prepare('SELECT setting_value FROM app_settings WHERE setting_key=? LIMIT 1');
    $st->execute([$key]);
    $row = $st->fetch();
    return $row ? (string)$row['setting_value'] : $default;
}
function set_setting(PDO $db, string $key, string $value): void {
    $st = $db->prepare('INSERT INTO app_settings (setting_key, setting_value, updated_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_at=VALUES(updated_at)');
    $st->execute([$key, $value, now_str()]);
}
function all_settings(): array {
    $db = db();
    return [
        'booking_close_hours'=>(float)get_setting($db, 'booking_close_hours', '1'),
        'cancel_close_hours'=>(float)get_setting($db, 'cancel_close_hours', '2'),
        'maintenance_mode'=>get_setting($db, 'maintenance_mode', '0') === '1',
        'maintenance_reason'=>get_setting($db, 'maintenance_reason', ''),
        'last_backup_at'=>get_setting($db, 'last_backup_at', ''),
    ];
}
function notify_user(int $userId, string $message): void {
    if ($userId <= 0) return;
    $st = db()->prepare('INSERT INTO notifications (user_id, message, is_read, created_at) VALUES (?, ?, 0, ?)');
    $st->execute([$userId, $message, now_str()]);
}
function notifications_for_current_user(): array {
    $u = current_user(); if (!$u) return [];
    $st = db()->prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 20');
    $st->execute([(int)$u['id']]);
    return array_map(fn($r)=>['id'=>(int)$r['id'], 'message'=>$r['message'], 'isRead'=>(int)$r['is_read']===1, 'createdAt'=>$r['created_at']], $st->fetchAll());
}
function approved_students_list(): array {
    $u=current_user(); if (!$u || !role_allowed($u, ['owner','clinic_management'])) return [];
    $rows = db()->query('SELECT * FROM approved_students ORDER BY name')->fetchAll();
    return array_map(fn($r)=>['id'=>(int)$r['id'], 'universityId'=>$r['university_id'], 'name'=>$r['name'], 'allowed'=>(int)$r['allowed']===1, 'createdAt'=>$r['created_at']], $rows);
}
function waiting_list_rows(): array {
    $u=current_user(); if (!$u) return [];
    if (role_allowed($u, ['owner','clinic_management','supervisor'])) {
        $rows = db()->query('SELECT w.*, u.name AS student_name, u.university_id, c.code AS course_code, c.name AS course_name FROM waiting_list w JOIN users u ON u.id=w.user_id JOIN courses c ON c.id=w.course_id ORDER BY w.booking_date DESC, w.session, w.created_at')->fetchAll();
    } else {
        $st = db()->prepare('SELECT w.*, u.name AS student_name, u.university_id, c.code AS course_code, c.name AS course_name FROM waiting_list w JOIN users u ON u.id=w.user_id JOIN courses c ON c.id=w.course_id WHERE w.user_id=? ORDER BY w.booking_date DESC, w.session, w.created_at');
        $st->execute([(int)$u['id']]); $rows = $st->fetchAll();
    }
    return array_map(fn($r)=>['id'=>(int)$r['id'], 'userId'=>(int)$r['user_id'], 'studentName'=>$r['student_name'], 'universityId'=>$r['university_id'], 'date'=>$r['booking_date'], 'session'=>$r['session'], 'courseId'=>(int)$r['course_id'], 'courseCode'=>$r['course_code'], 'courseName'=>$r['course_name'], 'status'=>$r['status'], 'notifiedAt'=>$r['notified_at'], 'createdAt'=>$r['created_at']], $rows);
}
function analytics_summary(): array {
    $rows = all_reservations();
    [$start, $end] = report_week_bounds(date('Y-m-d'));
    $week = array_values(array_filter($rows, fn($b)=>$b['date'] >= $start && $b['date'] <= $end));
    $active = array_values(array_filter($week, fn($b)=>!empty($b['active'])));
    $sessionCounts=[]; $courseCounts=[];
    foreach ($week as $b) { $sessionCounts[$b['session']] = ($sessionCounts[$b['session']] ?? 0)+1; $courseCounts[$b['courseCode']] = ($courseCounts[$b['courseCode']] ?? 0)+1; }
    arsort($sessionCounts); arsort($courseCounts);
    return [
        'totalWeek'=>count($week),
        'mostUsedSession'=> $sessionCounts ? session_label((string)array_key_first($sessionCounts)) : '-',
        'mostBookedCourse'=> $courseCounts ? (string)array_key_first($courseCounts) : '-',
        'absentStudents'=>count(array_filter($week, fn($b)=>($b['checkInStatus'] ?? '') === 'student_absent')),
        'cancelled'=>count(array_filter($week, fn($b)=>$b['status']==='cancelled')),
        'permissionNeeded'=>count(array_filter($active, fn($b)=>!empty($b['patientPermission']))),
        'brokenChairs'=>count(blocked_chairs()),
    ];
}
function weekly_schedule_summary(): array {
    [$start, $end] = report_week_bounds(date('Y-m-d'));
    $out=[]; $d=new DateTimeImmutable($start);
    for($i=0;$i<7;$i++){ $date=$d->modify('+' . $i . ' days')->format('Y-m-d'); $out[$date]=['date'=>$date,'day'=>(new DateTimeImmutable($date))->format('l'),'08:00'=>0,'11:00'=>0,'14:00'=>0]; }
    foreach (all_reservations() as $b) if(!empty($b['active']) && isset($out[$b['date']])) $out[$b['date']][$b['session']]++;
    return array_values($out);
}
function capacity_summaries(): array {
    $assignments = course_assignments(); $bookings = all_reservations(); $out=[];
    foreach ($assignments as $a) {
        $booked = count(array_filter($bookings, fn($b)=>!empty($b['active']) && (int)$b['courseId']===(int)$a['courseId'] && $b['date']===$a['date'] && $b['session']===$a['session']));
        $assigned = count($a['chairs']);
        $out[] = ['courseCode'=>$a['courseCode'], 'courseName'=>$a['courseName'], 'date'=>$a['date'], 'session'=>$a['session'], 'assigned'=>$assigned, 'booked'=>$booked, 'remaining'=>max(0,$assigned-$booked)];
    }
    return $out;
}
function find_next_waiter(string $date, string $session, int $courseId): ?array {
    $st = db()->prepare("SELECT * FROM waiting_list WHERE booking_date=? AND session=? AND course_id=? AND status='waiting' ORDER BY id ASC LIMIT 1");
    $st->execute([$date, $session, $courseId]);
    $row=$st->fetch(); return $row ?: null;
}
function booking_deadline_ok(string $date, string $session): bool {
    $settings = all_settings();
    return new DateTimeImmutable('now') <= hours_before_session($date, $session, (float)$settings['booking_close_hours']);
}
function cancellation_deadline_ok(string $date, string $session): bool {
    $settings = all_settings();
    return new DateTimeImmutable('now') <= hours_before_session($date, $session, (float)$settings['cancel_close_hours']);
}

function default_chairs(): array {
    return [
        ['number'=>26,'x'=>10,'y'=>14], ['number'=>25,'x'=>100,'y'=>14], ['number'=>24,'x'=>190,'y'=>14], ['number'=>23,'x'=>280,'y'=>14], ['number'=>22,'x'=>370,'y'=>14], ['number'=>21,'x'=>460,'y'=>14], ['number'=>20,'x'=>550,'y'=>14], ['number'=>19,'x'=>640,'y'=>14], ['number'=>18,'x'=>730,'y'=>14], ['number'=>17,'x'=>820,'y'=>14],
        ['number'=>9,'x'=>100,'y'=>92], ['number'=>10,'x'=>190,'y'=>92], ['number'=>11,'x'=>280,'y'=>92], ['number'=>12,'x'=>370,'y'=>92], ['number'=>13,'x'=>550,'y'=>92], ['number'=>14,'x'=>640,'y'=>92], ['number'=>15,'x'=>730,'y'=>92], ['number'=>16,'x'=>820,'y'=>92],
        ['number'=>5,'x'=>100,'y'=>170], ['number'=>6,'x'=>190,'y'=>170], ['number'=>7,'x'=>280,'y'=>170], ['number'=>8,'x'=>370,'y'=>170],
        ['number'=>4,'x'=>100,'y'=>248], ['number'=>3,'x'=>190,'y'=>248], ['number'=>2,'x'=>280,'y'=>248], ['number'=>1,'x'=>370,'y'=>248]
    ];
}

function courses_with_chairs(): array {
    $db = db();
    $courses = $db->query('SELECT * FROM courses ORDER BY code')->fetchAll();
    $assignmentRows = $db->query('SELECT course_id, assignment_date, session, chair_number FROM course_chair_assignments ORDER BY assignment_date, session, chair_number')->fetchAll();
    $legacyRows = $db->query('SELECT course_id, chair_number FROM course_chairs ORDER BY chair_number')->fetchAll();
    $assignmentsByCourse = [];
    foreach ($assignmentRows as $r) {
        $key = (int)$r['course_id'] . '|' . $r['assignment_date'] . '|' . $r['session'];
        if (!isset($assignmentsByCourse[$key])) {
            $assignmentsByCourse[$key] = [
                'courseId'=>(int)$r['course_id'],
                'date'=>$r['assignment_date'],
                'session'=>$r['session'],
                'chairs'=>[]
            ];
        }
        $assignmentsByCourse[$key]['chairs'][] = (int)$r['chair_number'];
    }
    $legacyMap = [];
    foreach ($legacyRows as $r) $legacyMap[(int)$r['course_id']][] = (int)$r['chair_number'];
    $courseAssignments = [];
    foreach ($assignmentsByCourse as $a) $courseAssignments[(int)$a['courseId']][] = $a;
    $out = [];
    foreach ($courses as $c) {
        $out[] = [
            'id'=>(int)$c['id'], 'code'=>$c['code'], 'name'=>$c['name'],
            'session'=>$c['session'] ?? '',
            'color'=>$c['color'] ?? '#2563eb', 'active'=>(int)$c['active'] === 1,
            'chairs'=>$legacyMap[(int)$c['id']] ?? [],
            'assignments'=>$courseAssignments[(int)$c['id']] ?? []
        ];
    }
    return $out;
}

function course_assignments(): array {
    $rows = db()->query("SELECT a.course_id, a.assignment_date, a.session, a.chair_number, c.code, c.name, c.active
        FROM course_chair_assignments a
        JOIN courses c ON c.id = a.course_id
        ORDER BY a.assignment_date DESC, a.session, c.code, a.chair_number")->fetchAll();
    $groups = [];
    foreach ($rows as $r) {
        $key = (int)$r['course_id'] . '|' . $r['assignment_date'] . '|' . $r['session'];
        if (!isset($groups[$key])) {
            $groups[$key] = [
                'courseId'=>(int)$r['course_id'],
                'courseCode'=>$r['code'],
                'courseName'=>$r['name'],
                'active'=>(int)$r['active'] === 1,
                'date'=>$r['assignment_date'],
                'session'=>$r['session'],
                'chairs'=>[]
            ];
        }
        $groups[$key]['chairs'][] = (int)$r['chair_number'];
    }
    return array_values($groups);
}

function all_reservations(): array {
    $st = db()->query("SELECT r.*, u.name AS account_name, u.university_id, c.code AS course_code, c.name AS course_name
        FROM reservations r
        JOIN users u ON u.id = r.user_id
        JOIN courses c ON c.id = r.course_id
        ORDER BY r.booking_date DESC, r.session, r.chair_number");
    $rows = [];
    foreach ($st->fetchAll() as $r) {
        $rows[] = [
            'id'=>(int)$r['id'], 'user_id'=>(int)$r['user_id'], 'date'=>$r['booking_date'], 'session'=>$r['session'],
            'courseId'=>(int)$r['course_id'], 'courseCode'=>$r['course_code'], 'courseName'=>$r['course_name'],
            'chairNumber'=>(int)$r['chair_number'], 'operatorName'=>$r['operator_name'], 'assistantName'=>$r['assistant_name'],
            'patientName'=>$r['patient_name'], 'patientPhone'=>$r['patient_phone'] ?? '', 'notes'=>$r['notes'] ?? '', 'supervisorName'=>$r['supervisor_name'], 'patientPermission'=>!empty($r['patient_permission']), 'permissionStatus'=>$r['permission_status'] ?? 'not_needed', 'checkInStatus'=>$r['check_in_status'] ?? 'not_checked', 'qrToken'=>$r['qr_token'] ?? '', 'lastCheckInAt'=>$r['last_check_in_at'] ?? '', 'status'=>$r['status'],
            'active'=>((int)$r['active_lock'] === 1), 'statusNote'=>$r['status_note'], 'accountName'=>$r['account_name'],
            'universityId'=>$r['university_id'], 'createdAt'=>$r['created_at'], 'updatedAt'=>$r['updated_at']
        ];
    }
    return $rows;
}

function all_users_for_owner(): array {
    $u = current_user();
    if (!$u || !role_allowed($u, ['owner','clinic_management'])) return [];
    if ($u['role'] === 'owner') {
        $rows = db()->query("SELECT id, name, university_id, role, must_change_password, created_at FROM users ORDER BY CASE role WHEN 'owner' THEN 0 WHEN 'clinic_management' THEN 1 WHEN 'supervisor' THEN 2 ELSE 3 END, name")->fetchAll();
    } else {
        $rows = db()->query("SELECT id, name, university_id, role, must_change_password, created_at FROM users WHERE role != 'owner' ORDER BY CASE role WHEN 'clinic_management' THEN 1 WHEN 'supervisor' THEN 2 ELSE 3 END, name")->fetchAll();
    }
    return array_map(fn($r)=>['id'=>(int)$r['id'], 'name'=>$r['name'], 'university_id'=>$r['university_id'], 'role'=>$r['role'], 'must_change_password'=>!empty($r['must_change_password']), 'created_at'=>$r['created_at']], $rows);
}

function supervisors_list(): array {
    $rows = db()->query("SELECT id, name, university_id FROM users WHERE role='supervisor' ORDER BY name")->fetchAll();
    return array_map(fn($r)=>['id'=>(int)$r['id'], 'name'=>$r['name'], 'university_id'=>$r['university_id']], $rows);
}

function blocked_chairs(): array {
    $rows = db()->query("SELECT * FROM blocked_chairs ORDER BY booking_date DESC, session, chair_number")->fetchAll();
    return array_map(fn($r)=>['id'=>(int)$r['id'], 'date'=>$r['booking_date'], 'session'=>$r['session'], 'chairNumber'=>(int)$r['chair_number'], 'reason'=>$r['reason'] ?? '', 'createdAt'=>$r['created_at']], $rows);
}
function audit_log(?int $userId, ?int $reservationId, string $action, string $details=''): void {
    $st = db()->prepare('INSERT INTO audit_logs (user_id, reservation_id, action, details, created_at) VALUES (?, ?, ?, ?, ?)');
    $st->execute([$userId, $reservationId, $action, $details, now_str()]);
}
function audit_logs(): array {
    // Hide full-access account actions from the visible audit log, except booking actions.
    // The rows may still exist in the database, but they are not returned to the UI.
    $rows = db()->query("SELECT a.*, u.name AS actor, u.role AS actor_role
        FROM audit_logs a
        LEFT JOIN users u ON u.id=a.user_id
        WHERE NOT (u.role = 'owner' AND a.action != 'booked')
        ORDER BY a.id DESC
        LIMIT 250")->fetchAll();
    return array_map(fn($r)=>['id'=>(int)$r['id'], 'actor'=>$r['actor'] ?? 'System', 'reservationId'=>$r['reservation_id'], 'action'=>$r['action'], 'details'=>$r['details'], 'createdAt'=>$r['created_at']], $rows);
}
function csv_download(string $filename, array $headers, array $rows): never {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo "\xEF\xBB\xBF"; // UTF-8 BOM for Excel
    echo "sep=,\r\n"; // makes Excel open comma-separated columns cleanly
    $out = fopen('php://output', 'w');
    fputcsv($out, $headers);
    foreach ($rows as $row) fputcsv($out, $row);
    fclose($out);
    exit;
}

function report_week_bounds(string $date): array {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');
    $base = new DateTimeImmutable($date);
    $dayOfWeek = (int)$base->format('w'); // 0 Sunday ... 6 Saturday
    $daysSinceSaturday = ($dayOfWeek - 6 + 7) % 7;
    $start = $base->modify('-' . $daysSinceSaturday . ' days');
    $end = $start->modify('+6 days');
    return [$start->format('Y-m-d'), $end->format('Y-m-d')];
}
function report_scope_data(array $rows, string $scope, string $date, bool $permissionOnly=false): array {
    if (!in_array($scope, ['date','week','full'], true)) $scope = 'date';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');
    [$weekStart, $weekEnd] = report_week_bounds($date);
    $filtered = array_values(array_filter($rows, function($b) use ($scope, $date, $weekStart, $weekEnd, $permissionOnly) {
        if ($permissionOnly && (empty($b['patientPermission']) || empty($b['active']))) return false;
        if ($scope === 'full') return true;
        if ($scope === 'week') return $b['date'] >= $weekStart && $b['date'] <= $weekEnd;
        return $b['date'] === $date;
    }));
    usort($filtered, fn($a, $b) => strcmp($a['date'] . $a['session'] . str_pad((string)$a['chairNumber'], 3, '0', STR_PAD_LEFT), $b['date'] . $b['session'] . str_pad((string)$b['chairNumber'], 3, '0', STR_PAD_LEFT)));
    return $filtered;
}
function report_scope_label(string $scope, string $date): string {
    if (!in_array($scope, ['date','week','full'], true)) $scope = 'date';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');
    if ($scope === 'full') return 'Full data';
    if ($scope === 'week') {
        [$start, $end] = report_week_bounds($date);
        return 'Whole week: ' . $start . ' to ' . $end;
    }
    return 'Date: ' . $date;
}
function clean_filename_part(string $s): string {
    return preg_replace('/[^A-Za-z0-9_\-]+/', '-', $s) ?: 'report';
}
function html_escape(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function render_print_report(array $rows, string $title, string $scopeLabel): never {
    header('Content-Type: text/html; charset=UTF-8');
    $printedAt = date('Y-m-d H:i');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>' . html_escape($title) . '</title>';
    echo '<style>body{font-family:Arial,sans-serif;color:#172554;margin:24px;background:#fff}h1{margin:0 0 6px}p{margin:4px 0 16px;color:#475569}.meta{display:flex;gap:18px;flex-wrap:wrap;margin-bottom:18px}.pill{background:#eef5f4;border:1px solid #dbe7e5;border-radius:999px;padding:8px 12px}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #cbd5e1;padding:8px;text-align:left;vertical-align:top}th{background:#f1f5f9;color:#0f172a}.muted{color:#64748b}.footer{margin-top:22px;font-size:12px;color:#64748b}@media print{button{display:none}body{margin:10mm}}</style>';
    echo '</head><body><button onclick="window.print()" style="padding:10px 14px;border:0;border-radius:10px;background:#2563eb;color:white;margin-bottom:14px">Print</button>';
    echo '<h1>' . html_escape($title) . '</h1><div class="meta"><span class="pill">' . html_escape($scopeLabel) . '</span><span class="pill">Generated: ' . html_escape($printedAt) . '</span><span class="pill">Total rows: ' . count($rows) . '</span></div>';
    if (!$rows) {
        echo '<p class="muted">No bookings found for this selection.</p>';
    } else {
        echo '<table><thead><tr><th>Date</th><th>Session</th><th>Chair</th><th>Course</th><th>Operator</th><th>Assistant</th><th>Patient</th><th>Phone</th><th>Permission</th><th>Supervisor</th><th>Status</th></tr></thead><tbody>';
        foreach ($rows as $b) {
            echo '<tr><td>'.html_escape($b['date']).'</td><td>'.html_escape(session_label($b['session'])).'</td><td>'.(int)$b['chairNumber'].'</td><td>'.html_escape($b['courseCode']).'</td><td>'.html_escape($b['operatorName']).'</td><td>'.html_escape($b['assistantName']).'</td><td>'.html_escape($b['patientName']).'</td><td>'.html_escape($b['patientPhone'] ?? '').'</td><td>'.(!empty($b['patientPermission'])?'Yes':'No').'</td><td>'.html_escape($b['supervisorName']).'</td><td>'.html_escape($b['status']).'</td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '<div class="footer">Powered By : Mujahid Jabbar & Dima Baraa</div><script>window.addEventListener("load",()=>setTimeout(()=>window.print(),350));</script></body></html>';
    exit;
}

function post_json(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $_POST;
}

if (isset($_GET['api']) && $_GET['api'] === 'db_setup') {
    try {
        $d = post_json();
        $providedSetupKey = (string)($_GET['setup'] ?? ($d['setup_key'] ?? ''));
        if (!hash_equals(SETUP_KEY, $providedSetupKey)) {
            throw new Exception('Setup access denied. Open the private setup link and try again.');
        }
        $cfg = [
            'host' => trim($d['host'] ?? 'localhost'),
            'port' => trim($d['port'] ?? '3306'),
            'database' => trim($d['database'] ?? ''),
            'username' => trim($d['username'] ?? ''),
            'password' => (string)($d['password'] ?? ''),
        ];
        $test = connect_mysql($cfg);
        init_db($test);
        save_mysql_config($cfg);
        json_out(['ok'=>true, 'message'=>'MySQL connected and database tables created successfully. Refreshing...']);
    } catch (Throwable $e) {
        json_out(['ok'=>false, 'message'=>'MySQL setup failed: ' . $e->getMessage()]);
    }
}

if (isset($_GET['qr'])) {
    try {
        $token = (string)$_GET['qr'];
        $st = db()->prepare("SELECT r.*, u.name AS account_name, c.code AS course_code, c.name AS course_name FROM reservations r JOIN users u ON u.id=r.user_id JOIN courses c ON c.id=r.course_id WHERE r.qr_token=? LIMIT 1");
        $st->execute([$token]); $b=$st->fetch();
        if(!$b) throw new Exception('Invalid booking QR code.');
        header('Content-Type: text/html; charset=UTF-8');
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Booking QR</title><style>body{font-family:Arial;background:#eef5f4;padding:20px;color:#17212b}.card{max-width:560px;margin:auto;background:white;border-radius:22px;padding:22px;box-shadow:0 14px 40px #0001}p{font-size:16px}</style></head><body><div class="card"><h1>Clinic Booking Confirmation</h1>';
        echo '<p><b>Student:</b> '.html_escape($b['account_name']).'</p><p><b>Patient:</b> '.html_escape($b['patient_name']).'</p><p><b>Date:</b> '.html_escape($b['booking_date']).'</p><p><b>Session:</b> '.html_escape(session_label($b['session'])).'</p><p><b>Chair:</b> '.(int)$b['chair_number'].'</p><p><b>Course:</b> '.html_escape($b['course_code']).' — '.html_escape($b['course_name']).'</p><p><b>Supervisor:</b> '.html_escape($b['supervisor_name']).'</p><p><b>Status:</b> '.html_escape($b['status']).'</p></div></body></html>'; exit;
    } catch (Throwable $e) { header('Content-Type:text/plain'); echo $e->getMessage(); exit; }
}

if (isset($_GET['api'])) {
    $api = $_GET['api'];
    $db = null;
    try {
        $db = db();
        if ($api === 'state') {
            $bounds = current_clinic_week_bounds();
            $cu = current_user();
            if (!$cu) {
                json_out(['ok'=>true, 'user'=>null, 'chairs'=>default_chairs(), 'courses'=>[], 'assignments'=>[], 'bookings'=>[], 'users'=>[], 'supervisors'=>[], 'blocked'=>[], 'audit'=>[], 'settings'=>all_settings(), 'approvedStudents'=>[], 'notifications'=>[], 'waitingList'=>[], 'analytics'=>[], 'weeklySchedule'=>[], 'capacity'=>[], 'today'=>date('Y-m-d'), 'weekStart'=>$bounds[0]->format('Y-m-d'), 'weekEnd'=>$bounds[1]->format('Y-m-d')]);
            }
            json_out(['ok'=>true, 'user'=>$cu, 'chairs'=>default_chairs(), 'courses'=>courses_with_chairs(), 'assignments'=>course_assignments(), 'bookings'=>all_reservations(), 'users'=>all_users_for_owner(), 'supervisors'=>supervisors_list(), 'blocked'=>blocked_chairs(), 'audit'=>audit_logs(), 'settings'=>all_settings(), 'approvedStudents'=>approved_students_list(), 'notifications'=>notifications_for_current_user(), 'waitingList'=>waiting_list_rows(), 'analytics'=>analytics_summary(), 'weeklySchedule'=>weekly_schedule_summary(), 'capacity'=>capacity_summaries(), 'today'=>date('Y-m-d'), 'weekStart'=>$bounds[0]->format('Y-m-d'), 'weekEnd'=>$bounds[1]->format('Y-m-d')]);
        }

        if ($api === 'register') {
            $d = post_json();
            $name = trim($d['name'] ?? '');
            $uid = trim($d['university_id'] ?? '');
            $pass = (string)($d['password'] ?? '');
            if ($name === '' || $uid === '' || strlen($pass) < 4) throw new Exception('Name, university ID, and password are required. Password must be at least 4 characters.');
            $st = $db->prepare('SELECT * FROM approved_students WHERE university_id=? AND allowed=1 LIMIT 1');
            $st->execute([$uid]);
            $approved = $st->fetch();
            if (!$approved) throw new Exception('This university ID is not approved for registration. Please contact clinic management.');
            if (strtolower(trim($approved['name'])) !== strtolower($name)) throw new Exception('The name must match the approved student list for this university ID.');
            $st = $db->prepare("INSERT INTO users (name, university_id, password_hash, role, must_change_password, created_at, updated_at) VALUES (?, ?, ?, 'student', 0, ?, ?)");
            $st->execute([$name, $uid, password_hash($pass, PASSWORD_DEFAULT), now_str(), now_str()]);
            $_SESSION['user_id'] = (int)$db->lastInsertId();
            json_out(['ok'=>true, 'message'=>'Account created successfully.']);
        }

        if ($api === 'login') {
            $d = post_json();
            $name = trim($d['name'] ?? '');
            $pass = (string)($d['password'] ?? '');
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            $since = (new DateTimeImmutable('now'))->modify('-5 minutes')->format('Y-m-d H:i:s');
            $st = $db->prepare('SELECT COUNT(*) AS c FROM login_attempts WHERE identifier=? AND ip_address=? AND success=0 AND created_at >= ?');
            $st->execute([$name, $ip, $since]);
            if ((int)$st->fetch()['c'] >= 5) throw new Exception('Too many attempts. Try again after 5 minutes.');
            $st = $db->prepare('SELECT * FROM users WHERE name = ? OR university_id = ? LIMIT 1');
            $st->execute([$name, $name]);
            $user = $st->fetch();
            if (!$user || !password_verify($pass, $user['password_hash'])) {
                $db->prepare('INSERT INTO login_attempts (identifier, ip_address, success, created_at) VALUES (?, ?, 0, ?)')->execute([$name, $ip, now_str()]);
                throw new Exception('Wrong name or password.');
            }
            $db->prepare('INSERT INTO login_attempts (identifier, ip_address, success, created_at) VALUES (?, ?, 1, ?)')->execute([$name, $ip, now_str()]);
            $_SESSION['user_id'] = (int)$user['id'];
            $msg = !empty($user['must_change_password']) ? 'Logged in. You must change your password.' : 'Logged in successfully.';
            json_out(['ok'=>true, 'message'=>$msg]);
        }

        if ($api === 'logout') {
            session_destroy();
            json_out(['ok'=>true, 'message'=>'Logged out.']);
        }

        if ($api === 'create_user') {
            $u = require_user();
            if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Only full-access or clinic management accounts can create accounts.');
            $d = post_json();
            $name = trim($d['name'] ?? '');
            $uid = trim($d['university_id'] ?? '');
            $role = $d['role'] ?? '';
            $pass = (string)($d['password'] ?? '');
            if (!in_array($role, ['student','supervisor','clinic_management'], true)) throw new Exception('Invalid role.');
            if ($name === '' || $uid === '' || strlen($pass) < 4) throw new Exception('Name, login ID, and password are required.');
            $st = $db->prepare('INSERT INTO users (name, university_id, password_hash, role, must_change_password, created_at, updated_at) VALUES (?, ?, ?, ?, 0, ?, ?)');
            $st->execute([$name, $uid, password_hash($pass, PASSWORD_DEFAULT), $role, now_str(), now_str()]);
            json_out(['ok'=>true, 'message'=>'Account created.']);
        }

        if ($api === 'delete_user') {
            $u = require_user();
            if (!role_allowed($u, ['owner'])) throw new Exception('Only full-access accounts can delete accounts.');
            $d = post_json();
            $id = (int)($d['id'] ?? 0);
            if ($id <= 0) throw new Exception('Missing account ID.');
            if (($d['confirm_text'] ?? '') !== 'DELETE') throw new Exception('Type DELETE to confirm account deletion.');
            if ($id === (int)$u['id']) throw new Exception('You cannot delete the account you are currently using.');
            $st = $db->prepare('SELECT id, name, university_id, role FROM users WHERE id=? LIMIT 1');
            $st->execute([$id]);
            $target = $st->fetch();
            if (!$target) throw new Exception('Account not found.');
            if ($target['role'] === 'owner') throw new Exception('Full-access accounts cannot be deleted from the website.');
            $db->beginTransaction();
            $db->prepare("UPDATE reservations SET status='cancelled', active_lock=NULL, status_note=CONCAT(COALESCE(status_note, ''), ' Account deleted.'), updated_at=? WHERE user_id=? AND active_lock=1")->execute([now_str(), $id]);
            $db->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
            audit_log((int)$u['id'], null, 'account_deleted', 'Deleted account: ' . $target['name'] . ' (' . ($target['university_id'] ?? '') . ')');
            $db->commit();
            json_out(['ok'=>true, 'message'=>'Account deleted. Active bookings for that account were cancelled.']);
        }

        if ($api === 'create_course' || $api === 'update_course') {
            $u = require_user();
            if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Only full-access or clinic management accounts can manage courses.');
            $d = post_json();
            $code = strtoupper(trim($d['code'] ?? ''));
            $name = trim($d['name'] ?? '');
            if ($code === '' || $name === '') throw new Exception('Course code and course name are required.');
            if ($api === 'create_course') {
                $st = $db->prepare('INSERT INTO courses (code, name, session, color, active, created_at, updated_at) VALUES (?, ?, ?, ?, 1, ?, ?)');
                $st->execute([$code, $name, '08:00', '#246b74', now_str(), now_str()]);
                json_out(['ok'=>true, 'message'=>'Course added. Now assign chairs for a specific date and session.']);
            } else {
                $courseId = (int)($d['id'] ?? 0);
                if ($courseId <= 0) throw new Exception('Missing course ID.');
                $active = !empty($d['active']) ? 1 : 0;
                $st = $db->prepare('UPDATE courses SET code=?, name=?, active=?, updated_at=? WHERE id=?');
                $st->execute([$code, $name, $active, now_str(), $courseId]);
                json_out(['ok'=>true, 'message'=>'Course updated.']);
            }
        }

        if ($api === 'assign_course_chairs') {
            $u = require_user();
            if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Only full-access or clinic management accounts can assign chairs.');
            $d = post_json();
            $courseId = (int)($d['courseId'] ?? 0);
            $date = $d['date'] ?? '';
            $session = $d['session'] ?? '';
            $chairs = array_values(array_unique(array_map('intval', $d['chairs'] ?? [])));
            if ($courseId <= 0) throw new Exception('Choose a course.');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !valid_session($session)) throw new Exception('Choose a valid date and session.');
            [$weekStart, $weekEnd] = current_clinic_week_bounds();
            $chosenDate = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
            if (!$chosenDate || $chosenDate < $weekStart || $chosenDate > $weekEnd) throw new Exception('Chair assignments are available only for the current clinic week (Saturday to Friday).');
            $chairs = array_values(array_filter($chairs, fn($ch)=>$ch >= 1 && $ch <= 26));
            if (count($chairs) === 0) throw new Exception('Select at least one chair.');
            $st = $db->prepare('SELECT id, code FROM courses WHERE id=? AND active=1');
            $st->execute([$courseId]);
            $course = $st->fetch();
            if (!$course) throw new Exception('Course not found or inactive.');
            $db->beginTransaction();
            foreach ($chairs as $ch) {
                $st = $db->prepare('SELECT a.course_id, c.code FROM course_chair_assignments a JOIN courses c ON c.id=a.course_id WHERE a.assignment_date=? AND a.session=? AND a.chair_number=? AND a.course_id != ? LIMIT 1');
                $st->execute([$date, $session, $ch, $courseId]);
                $conflict = $st->fetch();
                if ($conflict) throw new Exception('Chair ' . $ch . ' is already assigned to course ' . $conflict['code'] . ' on this date/session.');
            }
            $db->prepare('DELETE FROM course_chair_assignments WHERE course_id=? AND assignment_date=? AND session=?')->execute([$courseId, $date, $session]);
            $st = $db->prepare('INSERT INTO course_chair_assignments (course_id, assignment_date, session, chair_number, created_at) VALUES (?, ?, ?, ?, ?)');
            foreach ($chairs as $ch) $st->execute([$courseId, $date, $session, $ch, now_str()]);
            $db->commit();
            audit_log((int)$u['id'], null, 'chairs_assigned', 'Course ' . $course['code'] . ' assigned chairs ' . implode(',', $chairs) . ' for ' . $date . ' session ' . $session);
            json_out(['ok'=>true, 'message'=>'Chair assignment saved for this date/session only.']);
        }

        if ($api === 'delete_assignment_group') {
            $u = require_user();
            if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Only full-access or clinic management accounts can remove chair assignments.');
            $d = post_json();
            $courseId = (int)($d['courseId'] ?? 0);
            $date = $d['date'] ?? '';
            $session = $d['session'] ?? '';
            if ($courseId <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !valid_session($session)) throw new Exception('Invalid assignment.');
            if (($d['confirm_text'] ?? '') !== 'DELETE') throw new Exception('Type DELETE to confirm removing this assignment.');
            $db->prepare('DELETE FROM course_chair_assignments WHERE course_id=? AND assignment_date=? AND session=?')->execute([$courseId, $date, $session]);
            audit_log((int)$u['id'], null, 'chair_assignment_removed', 'Course assignment removed for ' . $date . ' session ' . $session);
            json_out(['ok'=>true, 'message'=>'Chair assignment removed.']);
        }

        if ($api === 'delete_course') {
            $u = require_user();
            if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Only full-access or clinic management accounts can delete courses.');
            $d = post_json();
            $courseId = (int)($d['id'] ?? 0);
            if (($d['confirm_text'] ?? '') !== 'DELETE') throw new Exception('Type DELETE to confirm course deletion.');
            $db->prepare('DELETE FROM courses WHERE id=?')->execute([$courseId]);
            json_out(['ok'=>true, 'message'=>'Course deleted.']);
        }

        if ($api === 'book') {
            $u = require_user();
            if (!role_allowed($u, ['owner','student'])) throw new Exception('Only students and full-access accounts can book chairs.');
            $d = post_json();
            $date = $d['date'] ?? '';
            $session = $d['session'] ?? '';
            $courseId = (int)($d['courseId'] ?? 0);
            $chairNo = (int)($d['chairNumber'] ?? 0);
            $operator = trim($d['operatorName'] ?? '');
            $assistant = trim($d['assistantName'] ?? '');
            $patient = trim($d['patientName'] ?? '');
            $patientPhone = trim($d['patientPhone'] ?? '');
            $notes = trim($d['notes'] ?? '');
            $supervisor = trim($d['supervisorName'] ?? '');
            $patientPermission = !empty($d['patientPermission']) ? 1 : 0;
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !valid_session($session)) throw new Exception('Choose a valid date and session.');
            $settings = all_settings();
            if (!empty($settings['maintenance_mode']) && $u['role'] !== 'owner') throw new Exception('Booking is temporarily closed. Reason: ' . ($settings['maintenance_reason'] ?: 'Schedule not finalized yet.'));
            [$weekStart, $weekEnd] = current_clinic_week_bounds();
            $chosenDate = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
            if (!$chosenDate || $chosenDate < $weekStart || $chosenDate > $weekEnd) {
                throw new Exception('Bookings are available only for the current clinic week (Saturday to Friday).');
            }
            if (!booking_deadline_ok($date, $session)) throw new Exception('Booking deadline passed for this session.');
            if (!$courseId || $chairNo < 1 || $chairNo > 26) throw new Exception('Choose a valid course and chair.');
            if ($operator === '' || $assistant === '' || $patient === '' || $supervisor === '') throw new Exception('Operator, assistant, patient, and supervisor are required.');
            $st = $db->prepare('SELECT id FROM users WHERE name=? AND role="supervisor" LIMIT 1');
            $st->execute([$supervisor]);
            if (!$st->fetch()) throw new Exception('Choose a supervisor from the approved supervisor list.');
            $st = $db->prepare('SELECT * FROM courses WHERE id=? AND active=1');
            $st->execute([$courseId]);
            $course = $st->fetch();
            if (!$course) throw new Exception('Course not found.');
            $st = $db->prepare('SELECT id FROM course_chair_assignments WHERE course_id=? AND assignment_date=? AND session=? AND chair_number=? LIMIT 1');
            $st->execute([$courseId, $date, $session, $chairNo]);
            if (!$st->fetch()) throw new Exception('This chair is not assigned to this course for the selected date and session.');
            $st = $db->prepare('SELECT id FROM blocked_chairs WHERE booking_date=? AND session=? AND chair_number=? LIMIT 1');
            $st->execute([$date, $session, $chairNo]);
            if ($st->fetch()) throw new Exception('This chair is blocked by clinic management for this session.');
            $db->beginTransaction();
            $st = $db->prepare('SELECT id FROM reservations WHERE user_id=? AND booking_date=? AND session=? AND active_lock=1 LIMIT 1');
            $st->execute([(int)$u['id'], $date, $session]);
            if ($st->fetch()) throw new Exception('You already have a booking in this same session. You can book another session, but not twice in the same session.');
            $st = $db->prepare('SELECT id FROM reservations WHERE booking_date=? AND session=? AND chair_number=? AND active_lock=1 LIMIT 1');
            $st->execute([$date, $session, $chairNo]);
            if ($st->fetch()) throw new Exception('This chair is already booked.');
            $qrToken = bin2hex(random_bytes(20));
            $permissionStatus = $patientPermission ? 'needed' : 'not_needed';
            $st = $db->prepare('INSERT INTO reservations (user_id, booking_date, session, course_id, chair_number, operator_name, assistant_name, patient_name, patient_phone, notes, supervisor_name, patient_permission, permission_status, check_in_status, qr_token, status, active_lock, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "not_checked", ?, "active", 1, ?, ?)');
            $st->execute([(int)$u['id'], $date, $session, $courseId, $chairNo, $operator, $assistant, $patient, $patientPhone, $notes, $supervisor, $patientPermission, $permissionStatus, $qrToken, now_str(), now_str()]);
            $newId = (int)$db->lastInsertId();
            $db->prepare("UPDATE waiting_list SET status='booked' WHERE user_id=? AND booking_date=? AND session=? AND course_id=? AND status IN ('waiting','notified')")->execute([(int)$u['id'], $date, $session, $courseId]);
            notify_user((int)$u['id'], 'Booking confirmed: Chair ' . $chairNo . ', ' . $date . ', ' . session_label($session) . '.');
            audit_log((int)$u['id'], $newId, 'booked', 'Chair ' . $chairNo . ' booked for ' . $date . ' session ' . $session);
            $db->commit();
            json_out(['ok'=>true, 'message'=>'Booking completed successfully. QR confirmation is available in your booking details.']);
        }

        if ($api === 'set_status') {
            $u = require_user();
            $d = post_json();
            $id = (int)($d['id'] ?? 0);
            $status = $d['status'] ?? '';
            $note = trim($d['note'] ?? '');
            $validStatuses = ['cancelled','excused','attended','checked_in','patient_arrived','patient_did_not_arrive','student_absent','case_completed'];
            if (!in_array($status, $validStatuses, true)) throw new Exception('Invalid status.');
            $st = $db->prepare('SELECT * FROM reservations WHERE id=?');
            $st->execute([$id]);
            $r = $st->fetch();
            if (!$r) throw new Exception('Booking not found.');
            $ownCancel = $status === 'cancelled' && (int)$r['user_id'] === (int)$u['id'];
            if ($ownCancel && !cancellation_deadline_ok($r['booking_date'], $r['session'])) throw new Exception('Cancellation deadline passed for this session. Contact the supervisor.');
            if (!$ownCancel && !role_allowed($u, ['owner','supervisor'])) throw new Exception('You are not allowed to adjust this booking.');
            $terminal = in_array($status, ['cancelled','excused'], true);
            $lock = $terminal ? null : 1;
            $checkStatus = in_array($status, ['checked_in','patient_arrived','patient_did_not_arrive','student_absent','case_completed'], true) ? $status : ($r['check_in_status'] ?? 'not_checked');
            $db->beginTransaction();
            $st = $db->prepare('UPDATE reservations SET status=?, active_lock=?, status_note=?, check_in_status=?, last_check_in_at=?, updated_at=? WHERE id=?');
            $visibleStatus = in_array($status, ['checked_in','patient_arrived','patient_did_not_arrive','student_absent','case_completed'], true) ? 'active' : $status;
            $st->execute([$visibleStatus, $lock, $note, $checkStatus, now_str(), now_str(), $id]);
            audit_log((int)$u['id'], $id, $status, $note);
            if ((int)$r['user_id'] !== (int)$u['id']) notify_user((int)$r['user_id'], 'Your booking #' . $id . ' was updated: ' . str_replace('_',' ', $status) . '.');
            if ($terminal) {
                $waiter = find_next_waiter($r['booking_date'], $r['session'], (int)$r['course_id']);
                if ($waiter) {
                    $db->prepare("UPDATE waiting_list SET status='notified', notified_at=? WHERE id=?")->execute([now_str(), (int)$waiter['id']]);
                    notify_user((int)$waiter['user_id'], 'A chair became available for your waiting list course on ' . $r['booking_date'] . ' at ' . session_label($r['session']) . '. Please book as soon as possible.');
                }
            }
            $db->commit();
            json_out(['ok'=>true, 'message'=>'Booking updated.']);
        }

        if ($api === 'switch') {
            $u = require_user();
            if (!role_allowed($u, ['owner','supervisor'])) throw new Exception('Only doctor supervisors and full-access accounts can switch bookings.');
            $d = post_json();
            $a = (int)($d['a'] ?? 0); $b = (int)($d['b'] ?? 0);
            if ($a <= 0 || $b <= 0 || $a === $b) throw new Exception('Choose two different booking IDs.');
            $st = $db->prepare('SELECT * FROM reservations WHERE id IN (?, ?) AND active_lock=1 AND status="active" ORDER BY id');
            $st->execute([$a, $b]);
            $rows = $st->fetchAll();
            if (count($rows) !== 2) throw new Exception('Both bookings must be active.');
            $r1 = $rows[0]; $r2 = $rows[1];
            if ($r1['booking_date'] !== $r2['booking_date'] || $r1['session'] !== $r2['session']) throw new Exception('Switching is only allowed within the same date/session.');
            $st = $db->prepare('SELECT id FROM course_chair_assignments WHERE course_id=? AND assignment_date=? AND session=? AND chair_number=? LIMIT 1');
            $st->execute([(int)$r1['course_id'], $r1['booking_date'], $r1['session'], (int)$r2['chair_number']]); if (!$st->fetch()) throw new Exception('First booking course is not assigned to the target chair on that date/session.');
            $st->execute([(int)$r2['course_id'], $r2['booking_date'], $r2['session'], (int)$r1['chair_number']]); if (!$st->fetch()) throw new Exception('Second booking course is not assigned to the target chair on that date/session.');
            $db->beginTransaction();
            $db->prepare('UPDATE reservations SET active_lock=NULL, updated_at=? WHERE id IN (?, ?)')->execute([now_str(), $a, $b]);
            $db->prepare('UPDATE reservations SET chair_number=?, active_lock=1, updated_at=? WHERE id=?')->execute([(int)$r2['chair_number'], now_str(), (int)$r1['id']]);
            $db->prepare('UPDATE reservations SET chair_number=?, active_lock=1, updated_at=? WHERE id=?')->execute([(int)$r1['chair_number'], now_str(), (int)$r2['id']]);
            audit_log((int)$u['id'], (int)$r1['id'], 'switched', 'Switched with booking #' . (int)$r2['id']);
            audit_log((int)$u['id'], (int)$r2['id'], 'switched', 'Switched with booking #' . (int)$r1['id']);
            notify_user((int)$r1['user_id'], 'Your booking #' . (int)$r1['id'] . ' was switched to chair ' . (int)$r2['chair_number'] . '.');
            notify_user((int)$r2['user_id'], 'Your booking #' . (int)$r2['id'] . ' was switched to chair ' . (int)$r1['chair_number'] . '.');
            $db->commit();
            json_out(['ok'=>true, 'message'=>'Bookings switched.']);
        }


        if ($api === 'block_chair') {
            $u = require_user();
            if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Only clinic management can block chairs.');
            $d = post_json();
            $date = $d['date'] ?? ''; $session = $d['session'] ?? ''; $chairNo = (int)($d['chairNumber'] ?? 0); $reason = trim($d['reason'] ?? '');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !valid_session($session) || $chairNo < 1 || $chairNo > 26) throw new Exception('Choose valid date, session, and chair.');
            if ($reason === '') throw new Exception('Please write the blocking reason.');
            $st=$db->prepare('SELECT id FROM reservations WHERE booking_date=? AND session=? AND chair_number=? AND active_lock=1 LIMIT 1'); $st->execute([$date,$session,$chairNo]);
            if ($st->fetch()) throw new Exception('Cannot block a chair that already has an active booking.');
            $st=$db->prepare('INSERT INTO blocked_chairs (booking_date, session, chair_number, reason, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE reason=VALUES(reason), created_by=VALUES(created_by), created_at=VALUES(created_at)');
            $st->execute([$date,$session,$chairNo,$reason,(int)$u['id'],now_str()]);
            audit_log((int)$u['id'], null, 'chair_blocked', 'Chair ' . $chairNo . ' blocked for ' . $date . ' session ' . $session . '. ' . $reason);
            json_out(['ok'=>true,'message'=>'Chair blocked.']);
        }

        if ($api === 'unblock_chair') {
            $u = require_user();
            if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Only clinic management can unblock chairs.');
            $d = post_json(); $id=(int)($d['id'] ?? 0);
            $db->prepare('DELETE FROM blocked_chairs WHERE id=?')->execute([$id]);
            audit_log((int)$u['id'], null, 'chair_unblocked', 'Blocked chair record #' . $id . ' removed.');
            json_out(['ok'=>true,'message'=>'Chair unblocked.']);
        }

        if ($api === 'add_approved_student') {
            $u = require_user(); if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Not allowed.');
            $d = post_json(); $uid=trim($d['university_id'] ?? ''); $name=trim($d['name'] ?? ''); $allowed=!empty($d['allowed'])?1:0;
            if ($uid==='' || $name==='') throw new Exception('Student name and university ID are required.');
            $st=$db->prepare('INSERT INTO approved_students (university_id, name, allowed, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), allowed=VALUES(allowed), updated_at=VALUES(updated_at)');
            $st->execute([$uid,$name,$allowed,(int)$u['id'],now_str(),now_str()]);
            audit_log((int)$u['id'], null, 'approved_student_saved', $name . ' / ' . $uid);
            json_out(['ok'=>true,'message'=>'Approved student saved.']);
        }

        if ($api === 'import_approved_students') {
            $u = require_user(); if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Not allowed.');
            $d = post_json(); $text=(string)($d['text'] ?? '');
            $count=0;
            foreach (preg_split('/
?
/', $text) as $line) {
                $line=trim($line); if($line==='') continue;
                $parts=array_map('trim', preg_split('/[,	;]/', $line));
                if(count($parts)<2) continue;
                $uid=$parts[0]; $name=$parts[1]; $allowed=isset($parts[2]) ? (int)((strtolower($parts[2])==='yes') || $parts[2]==='1' || strtolower($parts[2])==='allowed') : 1;
                if($uid==='' || $name==='') continue;
                $st=$db->prepare('INSERT INTO approved_students (university_id, name, allowed, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), allowed=VALUES(allowed), updated_at=VALUES(updated_at)');
                $st->execute([$uid,$name,$allowed,(int)$u['id'],now_str(),now_str()]); $count++;
            }
            audit_log((int)$u['id'], null, 'approved_students_imported', (string)$count . ' rows');
            json_out(['ok'=>true,'message'=>'Imported ' . $count . ' approved students.']);
        }

        if ($api === 'delete_approved_student') {
            $u = require_user(); if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Not allowed.');
            $d=post_json(); if(($d['confirm_text'] ?? '') !== 'DELETE') throw new Exception('Type DELETE to confirm deletion.');
            $db->prepare('DELETE FROM approved_students WHERE id=?')->execute([(int)($d['id'] ?? 0)]);
            json_out(['ok'=>true,'message'=>'Approved student deleted.']);
        }

        if ($api === 'update_settings') {
            $u = require_user(); if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Not allowed.');
            $d=post_json();
            set_setting($db, 'booking_close_hours', (string)max(0, (float)($d['booking_close_hours'] ?? 1)));
            set_setting($db, 'cancel_close_hours', (string)max(0, (float)($d['cancel_close_hours'] ?? 2)));
            set_setting($db, 'maintenance_mode', !empty($d['maintenance_mode']) ? '1':'0');
            set_setting($db, 'maintenance_reason', trim($d['maintenance_reason'] ?? ''));
            audit_log((int)$u['id'], null, 'settings_updated', 'Booking/cancellation deadlines and maintenance mode updated.');
            json_out(['ok'=>true,'message'=>'Settings saved.']);
        }

        if ($api === 'join_waitlist') {
            $u=require_user(); if(!role_allowed($u, ['owner','student'])) throw new Exception('Only students can join waiting list.');
            $d=post_json(); $date=$d['date'] ?? ''; $session=$d['session'] ?? ''; $courseId=(int)($d['courseId'] ?? 0);
            if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date) || !valid_session($session) || $courseId<=0) throw new Exception('Invalid waiting list request.');
            $st=$db->prepare('SELECT chair_number FROM course_chair_assignments WHERE course_id=? AND assignment_date=? AND session=?'); $st->execute([$courseId,$date,$session]);
            $chairs=array_map('intval', array_column($st->fetchAll(), 'chair_number'));
            if(!$chairs) throw new Exception('No chairs assigned to this course/session.');
            foreach($chairs as $ch){
                $st=$db->prepare('SELECT id FROM reservations WHERE booking_date=? AND session=? AND chair_number=? AND active_lock=1 LIMIT 1'); $st->execute([$date,$session,$ch]); $booked=$st->fetch();
                $st=$db->prepare('SELECT id FROM blocked_chairs WHERE booking_date=? AND session=? AND chair_number=? LIMIT 1'); $st->execute([$date,$session,$ch]); $blocked=$st->fetch();
                if(!$booked && !$blocked) throw new Exception('There is still an available chair. Please book directly instead of joining the waiting list.');
            }
            $st=$db->prepare("INSERT INTO waiting_list (user_id, booking_date, session, course_id, status, created_at) VALUES (?, ?, ?, ?, 'waiting', ?) ON DUPLICATE KEY UPDATE created_at=VALUES(created_at)");
            $st->execute([(int)$u['id'],$date,$session,$courseId,now_str()]);
            json_out(['ok'=>true,'message'=>'You joined the waiting list. You will be notified if a chair becomes available.']);
        }

        if ($api === 'set_permission_status') {
            $u=require_user(); if(!role_allowed($u, ['owner','clinic_management','supervisor'])) throw new Exception('Not allowed.');
            $d=post_json(); $id=(int)($d['id'] ?? 0); $status=$d['status'] ?? '';
            if(!in_array($status, ['not_needed','needed','sent_to_security','approved','rejected'], true)) throw new Exception('Invalid permission status.');
            $st=$db->prepare('SELECT user_id FROM reservations WHERE id=?'); $st->execute([$id]); $r=$st->fetch(); if(!$r) throw new Exception('Booking not found.');
            $db->prepare('UPDATE reservations SET permission_status=?, updated_at=? WHERE id=?')->execute([$status,now_str(),$id]);
            notify_user((int)$r['user_id'], 'Patient permission status updated for booking #' . $id . ': ' . str_replace('_',' ', $status) . '.');
            audit_log((int)$u['id'], $id, 'permission_status_updated', $status);
            json_out(['ok'=>true,'message'=>'Permission status updated.']);
        }

        if ($api === 'reset_password') {
            $u=require_user(); if(!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Not allowed.');
            $d=post_json(); $id=(int)($d['id'] ?? 0); $newPass=(string)($d['password'] ?? '');
            if(strlen($newPass)<4) throw new Exception('New password must be at least 4 characters.');
            $st=$db->prepare('SELECT role FROM users WHERE id=?'); $st->execute([$id]); $target=$st->fetch(); if(!$target) throw new Exception('Account not found.');
            if($target['role']==='owner' && $u['role']!=='owner') throw new Exception('Clinic management cannot reset full-access passwords.');
            $db->prepare('UPDATE users SET password_hash=?, must_change_password=1, updated_at=? WHERE id=?')->execute([password_hash($newPass, PASSWORD_DEFAULT), now_str(), $id]);
            audit_log((int)$u['id'], null, 'password_reset', 'Account #' . $id);
            json_out(['ok'=>true,'message'=>'Password reset. The user must change it after login.']);
        }

        if ($api === 'change_password') {
            $u=require_user(); $d=post_json(); $newPass=(string)($d['password'] ?? '');
            if(strlen($newPass)<4) throw new Exception('New password must be at least 4 characters.');
            $db->prepare('UPDATE users SET password_hash=?, must_change_password=0, updated_at=? WHERE id=?')->execute([password_hash($newPass, PASSWORD_DEFAULT), now_str(), (int)$u['id']]);
            json_out(['ok'=>true,'message'=>'Password changed successfully.']);
        }

        if ($api === 'mark_notifications_read') {
            $u=require_user(); $db->prepare('UPDATE notifications SET is_read=1 WHERE user_id=?')->execute([(int)$u['id']]);
            json_out(['ok'=>true,'message'=>'Notifications marked as read.']);
        }

        if ($api === 'export_setup') {
            $u=require_user(); if(!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Not allowed.');
            header('Content-Type: application/json; charset=UTF-8');
            header('Content-Disposition: attachment; filename="course-chair-setup-' . date('Y-m-d') . '.json"');
            echo json_encode(['courses'=>courses_with_chairs(), 'assignments'=>course_assignments()], JSON_PRETTY_PRINT); exit;
        }

        if ($api === 'import_setup') {
            $u=require_user(); if(!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Not allowed.');
            $d=post_json(); $text=(string)($d['json'] ?? ''); $data=json_decode($text,true); if(!is_array($data)) throw new Exception('Invalid JSON setup file/text.');
            $count=0;
            foreach(($data['assignments'] ?? []) as $a){
                $code=$a['courseCode'] ?? ''; if($code==='') continue;
                $st=$db->prepare('SELECT id FROM courses WHERE code=? LIMIT 1'); $st->execute([$code]); $c=$st->fetch(); if(!$c) continue;
                foreach(($a['chairs'] ?? []) as $ch){
                    $st=$db->prepare('INSERT IGNORE INTO course_chair_assignments (course_id, assignment_date, session, chair_number, created_at) VALUES (?, ?, ?, ?, ?)');
                    $st->execute([(int)$c['id'],$a['date'],$a['session'],(int)$ch,now_str()]); $count += $st->rowCount();
                }
            }
            audit_log((int)$u['id'], null, 'setup_imported', (string)$count . ' chair rows');
            json_out(['ok'=>true,'message'=>'Imported ' . $count . ' chair assignment rows.']);
        }

        if ($api === 'copy_last_week') {
            $u=require_user(); if(!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Not allowed.');
            [$start,$end]=report_week_bounds(date('Y-m-d')); $prevStart=(new DateTimeImmutable($start))->modify('-7 days'); $count=0;
            for($i=0;$i<7;$i++){
                $from=$prevStart->modify('+' . $i . ' days')->format('Y-m-d'); $to=(new DateTimeImmutable($start))->modify('+' . $i . ' days')->format('Y-m-d');
                $st=$db->prepare('SELECT course_id, session, chair_number FROM course_chair_assignments WHERE assignment_date=?'); $st->execute([$from]);
                foreach($st->fetchAll() as $r){ $ins=$db->prepare('INSERT IGNORE INTO course_chair_assignments (course_id, assignment_date, session, chair_number, created_at) VALUES (?, ?, ?, ?, ?)'); $ins->execute([(int)$r['course_id'],$to,$r['session'],(int)$r['chair_number'],now_str()]); $count += $ins->rowCount(); }
            }
            audit_log((int)$u['id'], null, 'last_week_copied', (string)$count . ' rows copied');
            json_out(['ok'=>true,'message'=>'Copied ' . $count . ' chair assignments from last week to this week.']);
        }

        if ($api === 'export_bookings') {
            $u = require_user();
            if (!role_allowed($u, ['owner','supervisor','clinic_management'])) throw new Exception('Not allowed.');
            $scope = $_GET['scope'] ?? 'date';
            $date = $_GET['date'] ?? date('Y-m-d');
            $rows = report_scope_data(all_reservations(), $scope, $date, false);
            $filePart = clean_filename_part(report_scope_label($scope, $date));
            csv_download('bookings-' . $filePart . '.csv', ['ID','Date','Session','Chair','Course','Operator','Assistant','Patient','Patient Phone','Permission','Supervisor','Booked By','Status','Notes'], array_map(fn($b)=>[$b['id'],$b['date'],session_label($b['session']),$b['chairNumber'],$b['courseCode'],$b['operatorName'],$b['assistantName'],$b['patientName'],$b['patientPhone'],$b['patientPermission']?'Yes':'No',$b['supervisorName'],$b['accountName'],$b['status'],$b['notes']], $rows));
        }

        if ($api === 'export_permission') {
            $u = require_user();
            if (!role_allowed($u, ['owner','supervisor','clinic_management'])) throw new Exception('Not allowed.');
            $scope = $_GET['scope'] ?? 'date';
            $date = $_GET['date'] ?? date('Y-m-d');
            $rows = report_scope_data(all_reservations(), $scope, $date, true);
            $filePart = clean_filename_part(report_scope_label($scope, $date));
            csv_download('AUIB-permission-list-' . $filePart . '.csv', ['Patient Name','Phone Number','Booking Date','Session Time'], array_map(fn($b)=>[$b['patientName'],$b['patientPhone'],$b['date'],session_label($b['session'])], $rows));
        }

        if ($api === 'print_schedule') {
            $u = require_user();
            if (!role_allowed($u, ['owner','supervisor','clinic_management'])) throw new Exception('Not allowed.');
            $scope = $_GET['scope'] ?? 'date';
            $date = $_GET['date'] ?? date('Y-m-d');
            $rows = report_scope_data(all_reservations(), $scope, $date, false);
            render_print_report($rows, 'Clinic Booking Schedule', report_scope_label($scope, $date));
        }

        if ($api === 'backup_db') {
            $u = require_user();
            if (!role_allowed($u, ['owner','clinic_management'])) throw new Exception('Not allowed.');
            mysql_backup_download();
        }

        throw new Exception('Unknown API endpoint.');
    } catch (Throwable $e) {
        if ($db instanceof PDO && $db->inTransaction()) $db->rollBack();
        json_out(['ok'=>false, 'message'=>$e->getMessage()]);
    }
}

$needsSetup = !config_exists();
$setupError = '';
if (!$needsSetup) {
    try { db(); }
    catch (Throwable $e) { $needsSetup = true; $setupError = $e->getMessage(); }
}
$setupUnlocked = isset($_GET['setup']) && hash_equals(SETUP_KEY, (string)$_GET['setup']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dental Clinic Reservation</title>
  <style>
    :root{
      --bg:#eef5f4;
      --bg-soft:#f7fbfa;
      --card:#ffffff;
      --text:#17212b;
      --muted:#64748b;
      --primary:#246b74;
      --primary-soft:#e4f3f4;
      --success:#2f855a;
      --success-soft:#e7f6ee;
      --danger:#c2413b;
      --danger-soft:#fdeceb;
      --warn:#b7791f;
      --warn-soft:#fff7db;
      --gray:#94a3b8;
      --gray-soft:#f1f5f9;
      --border:#d9e5e3;
      --shadow:0 14px 40px rgba(15,23,42,.07);
    }
    *{box-sizing:border-box}
    html{scroll-behavior:smooth}
    body{
      margin:0;
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,Helvetica,sans-serif;
      background:
        radial-gradient(circle at top left, rgba(36,107,116,.14), transparent 32%),
        linear-gradient(180deg,#f8fcfb 0%, var(--bg) 100%);
      color:var(--text);
      line-height:1.45;
      padding-bottom:42px;
    }
    .topbar{
      display:flex;justify-content:space-between;align-items:center;
      padding:16px 22px;background:rgba(255,255,255,.88);color:var(--text);
      gap:12px;flex-wrap:wrap;border-bottom:1px solid var(--border);
      position:sticky;top:0;z-index:30;backdrop-filter:blur(12px);
      box-shadow:0 6px 22px rgba(15,23,42,.045)
    }
    .topbar strong{font-size:18px;letter-spacing:.2px;color:#0f3f46}
    .topbar small{color:var(--muted)}
    .wrap{max-width:1220px;margin:22px auto;padding:0 16px}
    .card{
      background:rgba(255,255,255,.94);border:1px solid var(--border);border-radius:24px;
      padding:20px;margin-bottom:18px;box-shadow:var(--shadow)
    }
    h1,h2,h3{margin:0 0 12px;letter-spacing:-.02em;color:#102a31}
    h1{font-size:28px} h2{font-size:23px} h3{font-size:18px}
    .muted{color:var(--muted)}
    .grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
    .grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
    .grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
    .checkbox-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:9px;margin-top:8px}
    .check-card{border:1px solid var(--border);border-radius:14px;padding:10px;background:var(--bg-soft);font-weight:800;color:#334155;text-align:center}
    .check-card input{width:auto;margin-right:6px;accent-color:var(--primary)}
    .course-card{border:1px solid var(--border);border-radius:18px;padding:14px;background:var(--bg-soft);margin-bottom:10px}
    .stat-card{background:var(--bg-soft);border:1px solid var(--border);border-radius:18px;padding:15px}
    label{display:block;font-weight:800;margin:10px 0 6px;color:#334155}
    input,select,textarea{
      width:100%;padding:13px 14px;border:1px solid #cbdad8;border-radius:16px;font-size:16px;background:#fff;color:var(--text);
      outline:none;transition:border .15s, box-shadow .15s, background .15s
    }
    input:focus,select:focus,textarea:focus{border-color:var(--primary);box-shadow:0 0 0 4px rgba(36,107,116,.12)}
    textarea{min-height:88px;resize:vertical}
    button{border:0;border-radius:16px;padding:11px 16px;font-size:15px;font-weight:800;cursor:pointer;transition:transform .12s, box-shadow .12s, opacity .12s}
    button:hover{transform:translateY(-1px);box-shadow:0 8px 20px rgba(15,23,42,.08)}
    button:disabled{transform:none;box-shadow:none;cursor:not-allowed}
    .btn-primary{background:var(--primary);color:#fff}
    .btn-success{background:var(--success);color:#fff}
    .btn-danger{background:var(--danger);color:#fff}
    .btn-secondary{background:#334155;color:#fff}
    .btn-light{background:var(--primary-soft);color:#15515a}
    .btn-warn{background:var(--warn);color:#fff}
    .row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
    .hidden{display:none !important}
    .alert{padding:13px 15px;border-radius:16px;margin-bottom:14px;font-weight:800;border:1px solid transparent}
    .alert-success{background:var(--success-soft);color:#166534;border-color:#bbf7d0}
    .alert-error{background:var(--danger-soft);color:#991b1b;border-color:#fecaca}
    .alert-info{background:var(--primary-soft);color:#15515a;border-color:#bde5e8}
    .tabs{display:flex;gap:10px;flex-wrap:wrap}
    .tab{padding:10px 15px;border-radius:999px;background:#edf4f3;color:#334155;font-weight:800;cursor:pointer;border:1px solid var(--border)}
    .tab.active{background:var(--primary);color:#fff;border-color:var(--primary)}
    .session-btn{padding:18px;border:2px solid var(--border);border-radius:20px;background:var(--bg-soft);text-align:center;cursor:pointer;font-weight:800}
    .session-btn.active{border-color:var(--primary);background:var(--primary-soft);color:#0f3f46}
    .legend{display:flex;gap:10px;flex-wrap:wrap;margin-top:8px}
    .pill{display:inline-flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--border);border-radius:999px;padding:8px 12px;font-size:14px;color:#334155}
    .dot{width:13px;height:13px;border-radius:50%}
    .dot.av{background:var(--success)} .dot.bo{background:var(--danger)} .dot.bl{background:var(--warn)} .dot.na{background:var(--gray)} .dot.sel{background:var(--primary)}
    .chair-map{
      position:relative;min-height:540px;background:#fbfdfc;border:1px solid var(--border);border-radius:26px;overflow:auto;
      box-shadow:inset 0 0 0 1px rgba(255,255,255,.7)
    }
    .room-bg{position:absolute;inset:0;background:
      linear-gradient(90deg, transparent 0 80%, rgba(226,232,240,.45) 80% 100%),
      linear-gradient(180deg, rgba(248,250,252,.96), rgba(239,246,245,.96));
      opacity:1}
    .room-label{position:absolute;font-size:12px;color:#64748b;background:rgba(255,255,255,.92);padding:5px 8px;border-radius:10px;border:1px solid var(--border);font-weight:700}
    .chair{position:absolute;width:74px;height:56px;border-radius:18px;color:#fff;font-weight:900;display:flex;align-items:center;justify-content:center;border:2px solid rgba(255,255,255,.75);box-shadow:0 10px 24px rgba(15,23,42,.10);z-index:2}
    .chair.available{background:var(--success)}
    .chair.booked{background:var(--danger)}
    .chair.blocked{background:var(--warn)}
    .chair.unassigned{background:var(--gray)}
    .chair.selected{background:var(--primary)}
    .chair.own{outline:4px solid #7dd3fc}
    .chair:disabled{cursor:not-allowed;opacity:.9}
    .chair small{display:block;font-size:11px;font-weight:800;opacity:.95}
    table{width:100%;border-collapse:separate;border-spacing:0;background:#fff;border:1px solid var(--border);border-radius:16px;overflow:hidden}
    th,td{border-bottom:1px solid var(--border);padding:11px;text-align:left;vertical-align:top}
    tr:last-child td{border-bottom:0}
    th{background:#f3f8f7;color:#334155;font-size:13px;text-transform:uppercase;letter-spacing:.03em}
    .right{margin-left:auto}
    .badge{display:inline-block;padding:6px 10px;border-radius:999px;font-size:12px;font-weight:800}
    .badge-student{background:#e0e7ff;color:#3730a3}
    .badge-supervisor{background:#dcfce7;color:#166534}
    .badge-management{background:#fef3c7;color:#92400e}
    .badge-owner{background:#ede9fe;color:#5b21b6}
    .modal-backdrop{position:fixed;inset:0;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:16px;z-index:50;backdrop-filter:blur(5px)}
    .modal-card{background:#fff;border-radius:22px;max-width:580px;width:100%;padding:22px;box-shadow:0 24px 70px rgba(0,0,0,.22)}
    .small{font-size:13px}
    .powered-watermark{position:fixed;left:0;right:0;bottom:0;text-align:center;padding:8px 10px;background:rgba(255,255,255,.88);color:#315158;font-size:12px;font-weight:800;letter-spacing:.2px;z-index:40;backdrop-filter:blur(8px);border-top:1px solid var(--border)}
    body.dark{--bg:#0f172a;--bg-soft:#111827;--card:#182235;--text:#e5e7eb;--muted:#a7b0c0;--border:#334155;--shadow:0 14px 40px rgba(0,0,0,.32);background:#0f172a;color:var(--text)}
    body.dark .card, body.dark .topbar, body.dark .modal-card{background:#182235;color:var(--text)}
    body.dark input, body.dark select, body.dark textarea{background:#0f172a;color:#e5e7eb;border-color:#334155}
    body.dark table{background:#182235;color:#e5e7eb} body.dark th{background:#253246;color:#e5e7eb}
    @media (max-width:900px){.grid-2,.grid-3,.grid-4{grid-template-columns:1fr}.checkbox-grid{grid-template-columns:repeat(4,1fr)}.chair-map{min-height:720px}.topbar{position:static}.wrap{margin-top:14px}.card{border-radius:20px}}
  </style>
</head>
<body>
<div class="topbar">
  <div>
    <strong>Dental Clinic Reservation</strong><br>
    <small>University dental clinic booking system</small>
  </div>
  <div id="topUserArea" class="row"></div>
</div>

<?php if ($needsSetup): ?>
<div class="wrap">
  <section class="card">
    <h1>MySQL Setup</h1>
    <p class="muted">Enter the MySQL database details from your hosting control panel. The system will create its tables automatically.</p>
    <div id="setupAlerts"><?php if ($setupError): ?><div class="alert alert-error">Current MySQL connection failed: <?= html_escape($setupError) ?>. Re-enter the correct details below.</div><?php endif; ?></div>
    <div class="grid-2">
      <div><label>Database Host</label><input id="setupHost" value="localhost" placeholder="localhost"></div>
      <div><label>Port</label><input id="setupPort" value="3306" placeholder="3306"></div>
      <div><label>Database Name</label><input id="setupDatabase" placeholder="example_db"></div>
      <div><label>Database Username</label><input id="setupUsername" placeholder="example_user"></div>
      <div style="grid-column:1/-1"><label>Database Password</label><input id="setupPassword" type="password" placeholder="MySQL password"></div>
    </div>
    <div class="row" style="margin-top:14px"><button class="btn-primary" id="setupBtn">Save MySQL Settings</button></div>
    <p class="small muted" style="margin-top:12px">Create the MySQL database first in your hosting panel, then paste its exact name, username, and password here.</p>
  </section>
</div>
<script>
const SETUP_KEY_FOR_POST = <?= json_encode($setupUnlocked ? SETUP_KEY : '') ?>;
function setupMsg(type,msg){document.getElementById('setupAlerts').innerHTML=`<div class="alert alert-${type==='success'?'success':'error'}">${msg}</div>`}
document.getElementById('setupBtn').onclick = async () => {
  const payload = {
    host: document.getElementById('setupHost').value.trim(),
    port: document.getElementById('setupPort').value.trim() || '3306',
    database: document.getElementById('setupDatabase').value.trim(),
    username: document.getElementById('setupUsername').value.trim(),
    password: document.getElementById('setupPassword').value,
    setup_key: SETUP_KEY_FOR_POST
  };
  const res = await fetch('?api=db_setup&setup=' + encodeURIComponent(SETUP_KEY_FOR_POST), {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
  const data = await res.json();
  if(!data.ok) return setupMsg('error', data.message || 'Setup failed.');
  setupMsg('success', data.message || 'Setup completed.');
  setTimeout(()=>location.reload(), 900);
};
</script>
<div class="powered-watermark">Powered By : Mujahid Jabbar &amp; Dima Baraa</div>
</body>
</html>
<?php exit; endif; ?>

<div class="wrap">
  <div id="alerts"></div><div id="notificationsBox"></div>

  <section id="authSection" class="card">
    <div class="tabs" style="margin-bottom:14px">
      <div class="tab active" id="tabRegister">Register</div>
      <div class="tab" id="tabLogin">Login</div>
    </div>

    <div id="registerBox">
      <h2>Create student account</h2>
      <p class="muted">Students register first. Then they login using the exact same name and password.</p>
      <div class="grid-2">
        <div><label>Full name</label><input id="regName" placeholder="Student full name"></div>
        <div><label>University ID</label><input id="regUniversityId" placeholder="Example: 220045"></div>
        <div><label>Password</label><input id="regPassword" type="password" placeholder="Create password"></div>
      </div>
      <div class="row" style="margin-top:12px"><button class="btn-primary" id="registerBtn">Register</button></div>
      <p class="small muted" style="margin-top:10px">Students register here. Staff accounts are created by clinic management.</p>
    </div>

    <div id="loginBox" class="hidden">
      <h2>Login</h2>
      <div class="grid-2">
        <div><label>Full name or login ID</label><input id="loginName" placeholder="Enter registered name or login ID"></div>
        <div><label>Password</label><input id="loginPassword" type="password" placeholder="Enter password"></div>
      </div>
      <div class="row" style="margin-top:12px"><button class="btn-primary" id="loginBtn">Login</button></div>
      
    </div>
  </section>

  <section id="passwordChangeSection" class="card hidden">
    <h2>Change password required</h2>
    <p class="muted">Clinic management reset your password. Please create a new private password before continuing.</p>
    <div class="grid-2"><div><label>New password</label><input id="forcedNewPassword" type="password" placeholder="New password"></div></div>
    <button class="btn-primary" id="changePasswordBtn" style="margin-top:12px">Save new password</button>
  </section>

  <section id="sessionSection" class="card hidden">
    <h2>Select clinic session</h2>
    <p class="muted">Choose a date in the current clinic week (Saturday–Friday), then choose one of the three clinic sessions.</p>
    <div class="grid-4">
      <div><label>Date</label><input type="date" id="bookingDate"></div>
      <div class="session-btn" data-session="08:00"><h3>8:00</h3><div class="muted">Morning clinic</div></div>
      <div class="session-btn" data-session="11:00"><h3>11:00</h3><div class="muted">Midday clinic</div></div>
      <div class="session-btn" data-session="14:00"><h3>2:00</h3><div class="muted">Afternoon clinic</div></div>
    </div>
  </section>

  <section id="bookingFormSection" class="card hidden">
    <h2>Booking details</h2>
    <p class="muted">Fill these details, select the course from the clinic management list, then choose an allowed chair.</p>
    <div class="grid-2">
      <div><label>Student who will operate</label><input id="operatorName" placeholder="Operator student name"></div>
      <div><label>Student who will assist</label><input id="assistantName" placeholder="Assistant student name"></div>
      <div><label>Patient name</label><input id="patientName" placeholder="Patient full name"></div>
      <div><label>Patient phone number</label><input id="patientPhone" placeholder="Patient phone number"></div>
      <div style="grid-column:1/-1"><label>Optional notes</label><textarea id="bookingNotes" placeholder="Any special note for clinic staff"></textarea></div>
      <div><label>Supervisor doctor</label><select id="supervisorName"><option value="">Choose supervisor</option></select></div>
      <div>
        <label>Patient needs permission to enter AUIB?</label>
        <label class="check-card" style="display:inline-block;width:auto"><input type="checkbox" id="patientPermission"> Yes, patient needs entry permission</label>
      </div>
      <div>
        <label>Course</label><select id="courseSelect"><option value="">Choose course</option></select>
        <p class="small muted" id="courseHelp">Courses are added by the clinic management account and filtered by selected session.</p>
      </div>
    </div>
    <div class="row"><button class="btn-light" id="goToChairsBtn">Continue to chairs</button></div>
  </section>

  <section id="chairSection" class="card hidden">
    <div class="row" style="align-items:center">
      <div><h2>Choose chair</h2><div id="currentSelectionText" class="muted"></div></div>
      <div class="right row"><button class="btn-light" id="backToSessionsBtn">Back</button><button class="btn-light" id="refreshChairsBtn">Refresh chairs</button><button class="btn-primary" id="confirmBookingBtn">Confirm booking</button></div>
    </div>
    <div class="legend">
      <div class="pill"><span class="dot av"></span>Available</div><div class="pill"><span class="dot bo"></span>Booked</div><div class="pill"><span class="dot bl"></span>Not for selected course</div><div class="pill"><span class="dot sel"></span>Selected</div>
    </div>
    <p class="small muted">Automatic live refresh is disabled for speed. Tap “Refresh chairs” before confirming if many students are booking at the same time.</p>
    <div class="chair-map" id="chairMap" style="margin-top:14px">
      <div class="room-bg"></div>
      <div class="room-label" style="left:10px;top:84px">STR. Room</div>
      <div class="room-label" style="left:10px;top:152px">Disp. Room</div>
      <div class="room-label" style="left:10px;top:230px">IT + Elec. Room</div>
      <div class="room-label" style="left:575px;top:184px">Reception / W.C / service area</div>
    </div>
    <div id="waitlistActionBox" style="margin-top:12px"></div>
    <div id="myBookingBox" class="card" style="margin-top:16px;background:#f8fafc"></div>
  </section>

  <section id="managementSection" class="hidden">
    <div class="card">
      <div class="row" style="align-items:center"><div><h2 id="managementTitle">Management</h2><p class="muted" id="managementPanelSubtitle">Doctor supervisors can manage daily bookings. Clinic management can manage courses and chair assignments.</p></div></div>
    </div>
    <div class="card hidden" id="userManagementCard" style="background:#f8fafc">
      <h3>User accounts</h3>
      <div class="grid-4">
        <div><label>Name</label><input id="newUserName" placeholder="Full name"></div>
        <div><label>Login ID / University ID</label><input id="newUserId" placeholder="Example: supervisor01"></div>
        <div><label>Role</label><select id="newUserRole"><option value="supervisor">Doctor supervisor</option><option value="clinic_management">Clinic management</option><option value="student">Student</option></select></div>
        <div><label>Password</label><input id="newUserPassword" type="password" placeholder="Password"></div>
      </div>
      <button class="btn-success" id="createUserBtn" style="margin-top:12px">Create account</button>
      <div id="usersListBox" style="margin-top:14px"></div>
    </div>
    <div class="card hidden" id="approvedStudentsCard" style="background:#f8fafc">
      <h3>Approved student ID verification list</h3>
      <p class="muted">Only students added here can register. The registration name must match the approved name.</p>
      <div class="grid-4">
        <div><label>Student ID</label><input id="approvedStudentId" placeholder="Example: 1220406"></div>
        <div><label>Student name</label><input id="approvedStudentName" placeholder="Example: Mujahid Jabbar"></div>
        <div><label>Allowed?</label><select id="approvedStudentAllowed"><option value="1">Allowed</option><option value="0">Not allowed</option></select></div>
        <div style="align-self:end"><button class="btn-success" id="saveApprovedStudentBtn">Save student</button></div>
      </div>
      <label>Bulk import approved students</label>
      <textarea id="approvedBulkText" placeholder="One per line: 1220406, Mujahid Jabbar, Yes"></textarea>
      <button class="btn-light" id="importApprovedStudentsBtn" style="margin-top:8px">Import list</button>
      <div id="approvedStudentsBox" style="margin-top:14px"></div>
    </div>

    <div class="card hidden" id="courseManagementCard" style="background:#f8fafc">
      <h3>Clinic management: courses and date/session chair assignments</h3>
      <p class="muted">Add courses once, then assign chairs for a specific date and session only. A chair cannot be assigned to two courses at the same date and session.</p>
      <div class="grid-2">
        <div><label>Course code</label><input id="adminCourseCode" placeholder="Example: BDS540C"></div>
        <div><label>Course name</label><input id="adminCourseName" placeholder="Example: Removable Prosthodontics"></div>
      </div>
      <div class="row" style="margin-top:12px"><button class="btn-primary" id="addCourseBtn">Add course</button></div>
      <hr style="border:0;border-top:1px solid var(--border);margin:18px 0">
      <h3>Assign chairs to course for one date/session</h3>
      <div class="grid-3">
        <div><label>Date</label><input type="date" id="adminAssignmentDate"></div>
        <div><label>Session</label><select id="adminAssignmentSession"><option value="08:00">8:00</option><option value="11:00">11:00</option><option value="14:00">2:00</option></select></div>
        <div><label>Course</label><select id="adminAssignmentCourse"><option value="">Choose course</option></select></div>
      </div>
      <label>Select chairs for this course on this date/session</label><div class="checkbox-grid" id="adminChairChecks"></div>
      <div class="row" style="margin-top:12px"><button class="btn-success" id="assignCourseChairsBtn">Save chair assignment</button></div>
      <div id="courseListBox" style="margin-top:14px"></div>
    </div>
    <div class="card hidden" id="weeklySetupCard" style="background:#f8fafc">
      <h3>Weekly setup and blocked chairs</h3>
      <p class="muted">Clinic management can block a chair for a specific date/session if it is broken, under maintenance, or unavailable.</p>
      <div class="grid-4">
        <div><label>Date</label><input type="date" id="blockDate"></div>
        <div><label>Session</label><select id="blockSession"><option value="08:00">8:00</option><option value="11:00">11:00</option><option value="14:00">2:00</option></select></div>
        <div><label>Chair number</label><select id="blockChair"></select></div>
        <div><label>Reason</label><input id="blockReason" placeholder="Example: maintenance"></div>
      </div>
      <button class="btn-warn" id="blockChairBtn" style="margin-top:12px">Block chair</button>
      <div id="blockedChairsBox" style="margin-top:14px"></div>
    </div>

    <div class="card hidden" id="settingsCard" style="background:#f8fafc">
      <h3>Booking rules, maintenance mode, and setup tools</h3>
      <div class="grid-4">
        <div><label>Booking closes before session (hours)</label><input id="bookingCloseHours" type="number" step="0.5" min="0" value="1"></div>
        <div><label>Cancellation closes before session (hours)</label><input id="cancelCloseHours" type="number" step="0.5" min="0" value="2"></div>
        <div><label>Maintenance mode</label><select id="maintenanceMode"><option value="0">Open booking</option><option value="1">Close booking temporarily</option></select></div>
        <div><label>Maintenance reason</label><input id="maintenanceReason" placeholder="Schedule not finalized yet"></div>
      </div>
      <div class="row" style="margin-top:12px"><button class="btn-primary" id="saveSettingsBtn">Save settings</button><button class="btn-light" id="copyLastWeekBtn">Copy last week’s setup to this week</button><button class="btn-success" id="exportSetupBtn">Export course setup</button></div>
      <label>Import course setup JSON</label><textarea id="setupImportText" placeholder="Paste exported setup JSON here"></textarea><button class="btn-light" id="importSetupBtn">Import setup</button>
      <div id="backupReminderBox" style="margin-top:12px"></div>
    </div>

    <div class="card" id="dashboardAnalyticsCard">
      <h3>Dashboard analytics and weekly schedule</h3>
      <div id="analyticsBox" class="grid-4"></div>
      <h4>Current week overview</h4>
      <div id="weeklyScheduleBox"></div>
      <h4>Course capacity summary</h4>
      <div id="capacityBox"></div>
      <h4>Waiting list</h4>
      <div id="waitingListBox"></div>
    </div>

    <div class="card" id="reportsCard">
      <h3>Reports, permission list, backup, and print</h3>
      <div id="summaryBox" class="grid-4"></div>
      <div class="row" style="margin-top:12px">
        <button class="btn-primary" id="printBtn">Print daily schedule</button>
        <button class="btn-success" id="exportBookingsBtn">Export all bookings CSV</button>
        <button class="btn-warn" id="exportPermissionBtn">Export permission list CSV</button>
        <button class="btn-secondary hidden" id="backupBtn">Download database backup</button>
      </div>
      <div id="permissionListBox" style="margin-top:14px"></div>
    </div>

    <div class="card">
      <h3>Booking rules</h3>
      <ul>
        <li>Booking is available only for the current clinic week: Saturday to Friday.</li>
        <li>A student can book more than one session, but cannot book twice in the same session.</li>
        <li>Students can only book chairs assigned to their selected course for the selected date and session.</li>
        <li>Clinic management can block unavailable chairs and manage date/session-specific course chair assignments.</li>
        <li>Doctor supervisors can view daily bookings, cancel, excuse, mark attended, and switch bookings.</li>
      </ul>
    </div>

    <div class="card">
      <h3>Audit log and booking history</h3>
      <div id="auditBox" style="max-height:260px;overflow:auto"></div>
    </div>

    <div class="card">
      <h3>Doctor supervisor: bookings list</h3>
      <div class="grid-4">
        <div><label>Date</label><input type="date" id="adminDate"></div>
        <div><label>Session</label><select id="adminSession"><option value="all">All sessions</option><option value="08:00">8:00</option><option value="11:00">11:00</option><option value="14:00">2:00</option></select></div>
        <div><label>Supervisor</label><select id="adminFilterSupervisor"><option value="all">All supervisors</option></select></div>
        <div><label>Course</label><select id="adminFilterCourse"><option value="all">All courses</option></select></div>
        <div><label>Chair</label><input id="adminFilterChair" type="number" min="1" max="26" placeholder="Any chair"></div>
        <div><label>Permission</label><select id="adminFilterPermission"><option value="all">All</option><option value="needed">Permission needed</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></div>
        <div style="align-self:end"><button class="btn-primary" id="refreshAdminBtn">Show bookings</button></div>
      </div>
      <div class="grid-3" style="margin-top:10px">
        <div><label>First booking ID</label><input id="switchA" type="number" placeholder="Booking ID"></div>
        <div><label>Second booking ID</label><input id="switchB" type="number" placeholder="Booking ID"></div>
        <div style="align-self:end"><button class="btn-warn" id="switchBtn">Switch between two bookings</button></div>
      </div>
      <div style="overflow:auto;margin-top:14px"><table><thead><tr><th>ID</th><th>Date</th><th>Session</th><th>Chair</th><th>Course</th><th>Operator</th><th>Assistant</th><th>Patient</th><th>Phone</th><th>Entry permission/status</th><th>Supervisor</th><th>Booked by</th><th>Check-in</th><th>Status</th><th>Actions</th></tr></thead><tbody id="adminBookingsBody"></tbody></table></div>
    </div>
  </section>
</div>

<div id="detailsModal" class="modal-backdrop hidden"><div class="modal-card"><h2 id="detailsTitle">Booking details</h2><div id="detailsContent"></div><div class="row" style="margin-top:14px"><button class="btn-light" id="closeDetailsBtn">Close</button></div></div></div>
<div id="reportModal" class="modal-backdrop hidden">
  <div class="modal-card">
    <h2 id="reportModalTitle">Choose report range</h2>
    <p class="muted">Select the date you want, then choose whether to use that date only, the whole Saturday–Friday week, or all saved data.</p>
    <label>Date</label>
    <input type="date" id="reportDate">
    <div class="grid-3" style="margin-top:14px">
      <button class="btn-primary" id="reportDateOnlyBtn">Selected date</button>
      <button class="btn-success" id="reportWeekBtn">Whole week</button>
      <button class="btn-warn" id="reportFullBtn">Full data</button>
    </div>
    <div class="row" style="margin-top:14px">
      <button class="btn-light" id="closeReportModalBtn">Cancel</button>
    </div>
  </div>
</div>

<script>
const api = (name, body=null) => fetch(`?api=${name}`, {method: body ? 'POST':'GET', headers:{'Content-Type':'application/json'}, body: body ? JSON.stringify(body) : null}).then(r=>r.json());
const appState = {currentUser:null, chairs:[], courses:[], assignments:[], bookings:[], users:[], supervisors:[], blocked:[], audit:[], settings:{}, approvedStudents:[], notifications:[], waitingList:[], analytics:{}, weeklySchedule:[], capacity:[], selectedDate:'', selectedSession:'08:00', selectedCourseId:'', selectedChairNumber:null, currentView:(localStorage.getItem('clinicCurrentView') || 'booking')};

function escapeHtml(str){ return String(str ?? '').replace(/[&<>'"]/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[s])); }
function escapeJs(str){ return String(str ?? '').replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/[\r\n]+/g, ' '); }
function displaySession(s){ return s === '14:00' ? '2:00' : s; }
function roleLabel(r){ return ({owner:'Full access', clinic_management:'Clinic management', supervisor:'Doctor supervisor', student:'Student'}[r] || r); }
function roleBadge(r){ return ({owner:'badge-owner', clinic_management:'badge-management', supervisor:'badge-supervisor', student:'badge-student'}[r] || 'badge-student'); }
function showAlert(type,msg){ const el=document.getElementById('alerts'); el.innerHTML=`<div class="alert alert-${type==='error'?'error':'success'}">${escapeHtml(msg)}</div>`; setTimeout(()=>{ el.innerHTML=''; }, 4500); window.scrollTo({top:0,behavior:'smooth'}); }
function qs(id){ return document.getElementById(id); }
function hideAll(){ ['authSection','passwordChangeSection','sessionSection','bookingFormSection','chairSection','managementSection'].forEach(id=>qs(id).classList.add('hidden')); }
function clampToCurrentClinicWeek(dateValue, weekStart, weekEnd){
  if(!dateValue || dateValue < weekStart) return weekStart;
  if(dateValue > weekEnd) return weekEnd;
  return dateValue;
}
function setCalendarLimits(weekStart, weekEnd){
  ['bookingDate','adminDate','blockDate','adminAssignmentDate'].forEach(id=>{
    const el = qs(id);
    if(!el) return;
    el.min = weekStart;
    el.max = weekEnd;
    el.title = `Choose a date in the current clinic week: ${weekStart} to ${weekEnd}.`;
  });
}

async function loadState(){
  const preservedView = appState.currentView || localStorage.getItem('clinicCurrentView') || 'booking';
  const res = await api('state');
  if(!res.ok){ showAlert('error', res.message || 'Could not load app.'); return; }
  appState.currentUser = res.user;
  appState.chairs = res.chairs || [];
  appState.courses = res.courses || [];
  appState.assignments = res.assignments || [];
  appState.bookings = res.bookings || [];
  appState.users = res.users || [];
  appState.supervisors = res.supervisors || [];
  appState.blocked = res.blocked || [];
  appState.audit = res.audit || [];
  appState.settings = res.settings || {};
  appState.approvedStudents = res.approvedStudents || [];
  appState.notifications = res.notifications || [];
  appState.waitingList = res.waitingList || [];
  appState.analytics = res.analytics || {};
  appState.weeklySchedule = res.weeklySchedule || [];
  appState.capacity = res.capacity || [];
  appState.currentView = preservedView;
  const today = res.today || new Date().toISOString().slice(0,10);
  const weekStart = res.weekStart || today;
  const weekEnd = res.weekEnd || today;
  setCalendarLimits(weekStart, weekEnd);
  appState.selectedDate = clampToCurrentClinicWeek(appState.selectedDate || today, weekStart, weekEnd);
  qs('bookingDate').value = appState.selectedDate;
  qs('adminDate').value = clampToCurrentClinicWeek(qs('adminDate').value || appState.selectedDate, weekStart, weekEnd);
  if(qs('blockDate')) qs('blockDate').value = clampToCurrentClinicWeek(qs('blockDate').value || appState.selectedDate, weekStart, weekEnd);
  if(qs('adminAssignmentDate')) qs('adminAssignmentDate').value = clampToCurrentClinicWeek(qs('adminAssignmentDate').value || appState.selectedDate, weekStart, weekEnd);
  renderAll();
}

function renderAll(){ renderTopbar(); renderNotifications(); renderAuthOrApp(); renderSessionButtons(); renderCourseSelect(); renderSupervisorSelect(); renderChairMap(); renderMyBookings(); renderManagement(); }
function renderTopbar(){
  const box=qs('topUserArea');
  const unread=(appState.notifications||[]).filter(n=>!n.isRead).length;
  const curTheme = localStorage.getItem('theme') || 'light';
  const themeBtn = `<select onchange="setTheme(this.value)" style="width:auto;min-width:92px"><option value="light" ${curTheme==='light'?'selected':''}>Light</option><option value="dark" ${curTheme==='dark'?'selected':''}>Dark</option><option value="auto" ${curTheme==='auto'?'selected':''}>Auto</option></select>`;
  if(!appState.currentUser){ box.innerHTML=themeBtn + '<span class="small muted">Not logged in</span>'; return; }
  const u=appState.currentUser;
  box.innerHTML = themeBtn + `<button class="btn-light" onclick="goBooking()">Booking</button>` +
    (['owner','supervisor','clinic_management'].includes(u.role)?`<button class="btn-light" onclick="goManagement()">Management</button>`:'') +
    (unread?`<span class="badge badge-management">${unread} new</span>`:'') +
    `<span>${escapeHtml(u.name)} · <span class="badge ${roleBadge(u.role)}">${roleLabel(u.role)}</span></span><button class="btn-danger" onclick="logout()">Logout</button>`;
}
function applyTheme(){ const t=localStorage.getItem('theme')||'light'; const dark = t==='dark' || (t==='auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches); document.body.classList.toggle('dark', dark); }
function setTheme(t){ localStorage.setItem('theme', t); applyTheme(); renderTopbar(); }
function toggleTheme(){ const cur=localStorage.getItem('theme')||'light'; setTheme(cur==='dark'?'auto':cur==='auto'?'light':'dark'); }
applyTheme(); if(window.matchMedia){ window.matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', applyTheme); }
function renderNotifications(){
  const box=qs('notificationsBox'); if(!box) return;
  if(!appState.currentUser || !(appState.notifications||[]).length){ box.innerHTML=''; return; }
  const rows=appState.notifications.slice(0,5).map(n=>`<li>${escapeHtml(n.message)} <span class="small muted">${escapeHtml(n.createdAt)}</span></li>`).join('');
  box.innerHTML=`<section class="card" style="background:#f8fafc"><div class="row"><div><strong>Notifications</strong><ul>${rows}</ul></div><button class="btn-light right" onclick="markNotificationsRead()">Mark read</button></div></section>`;
}

function renderAuthOrApp(){
  if(!appState.currentUser){ hideAll(); qs('authSection').classList.remove('hidden'); return; }
  if(appState.currentUser.must_change_password || appState.currentUser.mustChangePassword){ hideAll(); qs('passwordChangeSection').classList.remove('hidden'); return; }

  // Clinic management and supervisors should always stay in the management panel.
  if(['clinic_management','supervisor'].includes(appState.currentUser.role)){
    appState.currentView='management';
    localStorage.setItem('clinicCurrentView','management');
    goManagement(false);
    return;
  }

  // Full-access accounts can use both Booking and Management. Preserve the last selected view.
  if(appState.currentUser.role === 'owner'){
    const savedView = appState.currentView || localStorage.getItem('clinicCurrentView') || 'booking';
    if(savedView === 'management') goManagement(false); else goBooking(false);
    return;
  }

  // Students always open the booking flow.
  appState.currentView='booking';
  localStorage.setItem('clinicCurrentView','booking');
  goBooking(false);
}
function goBooking(scroll=true){
  if(!appState.currentUser) return;
  appState.currentView='booking';
  localStorage.setItem('clinicCurrentView','booking');
  hideAll();
  if(['owner','student'].includes(appState.currentUser.role)){
    qs('sessionSection').classList.remove('hidden');
    qs('bookingFormSection').classList.remove('hidden');
    qs('chairSection').classList.remove('hidden');
  } else {
    goManagement(false);
  }
  if(scroll) window.scrollTo({top:0, behavior:'smooth'});
}
function goManagement(scroll=true){
  if(!appState.currentUser) return;
  appState.currentView='management';
  localStorage.setItem('clinicCurrentView','management');
  hideAll();
  qs('managementSection').classList.remove('hidden');
  if(scroll) window.scrollTo({top:0, behavior:'smooth'});
}

function renderSessionButtons(){
  document.querySelectorAll('.session-btn').forEach(btn=>btn.classList.toggle('active', btn.dataset.session === appState.selectedSession));
}
function assignmentsForSelectedDateSession(){ return appState.assignments.filter(a => a.active && a.date === appState.selectedDate && a.session === appState.selectedSession); }
function assignmentForCourse(courseId, date=appState.selectedDate, session=appState.selectedSession){ return appState.assignments.find(a => String(a.courseId) === String(courseId) && a.date === date && a.session === session); }
function coursesForSelectedSession(){ const ids = new Set(assignmentsForSelectedDateSession().map(a=>String(a.courseId))); return appState.courses.filter(c => c.active && ids.has(String(c.id))); }
function selectedCourse(){ return appState.courses.find(c => String(c.id) === String(appState.selectedCourseId)); }
function courseLabel(c){ return c ? `${c.code} — ${c.name}` : '-'; }
function renderCourseSelect(){
  const select=qs('courseSelect'); const courses=coursesForSelectedSession();
  select.innerHTML = `<option value="">Choose course</option>` + courses.map(c=>`<option value="${c.id}">${escapeHtml(courseLabel(c))}</option>`).join('');
  if(!courses.some(c=>String(c.id)===String(appState.selectedCourseId))) appState.selectedCourseId='';
  select.value=appState.selectedCourseId;
  qs('courseHelp').textContent = courses.length ? 'Only chairs assigned to this course for the selected date/session will be available.' : 'No course has chair assignments for this date/session yet. Clinic management must assign chairs first.';
}
function renderSupervisorSelect(){
  const select=qs('supervisorName');
  if(!select) return;
  const current=select.value;
  if(!appState.supervisors.length){
    select.innerHTML = `<option value="">No supervisors added yet</option>`;
    return;
  }
  select.innerHTML = `<option value="">Choose supervisor</option>` + appState.supervisors.map(s=>`<option value="${escapeHtml(s.name)}">${escapeHtml(s.name)}</option>`).join('');
  if(appState.supervisors.some(s=>s.name===current)) select.value=current;
}
function activeBookingForChair(date, session, chairNo){ return appState.bookings.find(b => b.active && b.date===date && b.session===session && Number(b.chairNumber)===Number(chairNo)); }
function myActiveBookings(){ if(!appState.currentUser) return []; return appState.bookings.filter(b => b.active && Number(b.user_id)===Number(appState.currentUser.id)); }
function renderChairMap(){
  const map=qs('chairMap');
  map.querySelectorAll('.chair').forEach(x=>x.remove());
  const course=selectedCourse();
  appState.chairs.forEach(ch=>{
    const existing=activeBookingForChair(appState.selectedDate, appState.selectedSession, ch.number);
    const assignment = course ? assignmentForCourse(course.id) : null;
    const allowed=assignment && assignment.chairs.includes(ch.number);
    const blocked=appState.blocked.find(x=>x.date===appState.selectedDate && x.session===appState.selectedSession && Number(x.chairNumber)===Number(ch.number));
    let cls='unassigned';
    if(existing) cls='booked'; else if(blocked) cls='blocked'; else if(allowed) cls='available';
    if(appState.selectedChairNumber === ch.number && !existing && allowed && !blocked) cls='selected';
    if(existing && appState.currentUser && Number(existing.user_id) === Number(appState.currentUser.id)) cls += ' own';
    const btn=document.createElement('button'); btn.className=`chair ${cls}`; btn.style.left=ch.x+'px'; btn.style.top=ch.y+'px'; btn.type='button';
    btn.title = blocked ? `Blocked: ${blocked.reason || 'No reason written'}` : (existing ? 'Click to view booking details' : (allowed ? 'Available' : 'Not assigned to this course'));
    btn.innerHTML=`<div>${ch.number}<br><small>${existing?'Booked':(blocked?'Blocked':(allowed?'Available':'Not assigned'))}</small></div>`;
    btn.onclick=()=>{ if(existing) showDetails(existing); else if(blocked) showBlockedReason(ch.number, blocked); else if(allowed){ appState.selectedChairNumber=ch.number; renderChairMap(); updateCurrentSelectionText(); } else showAlert('error', 'This chair is not assigned to the selected course.'); };
    map.appendChild(btn);
  });
  updateCurrentSelectionText();
  renderWaitlistAction();
}
function selectedCourseAvailability(){
  const course=selectedCourse(); if(!course) return {assigned:0,available:0};
  const assignment=assignmentForCourse(course.id); if(!assignment) return {assigned:0,available:0};
  let available=0;
  assignment.chairs.forEach(ch=>{ const existing=activeBookingForChair(appState.selectedDate, appState.selectedSession, ch); const blocked=appState.blocked.find(x=>x.date===appState.selectedDate && x.session===appState.selectedSession && Number(x.chairNumber)===Number(ch)); if(!existing && !blocked) available++; });
  return {assigned:assignment.chairs.length, available};
}
function renderWaitlistAction(){
  const box=qs('waitlistActionBox'); if(!box) return; const course=selectedCourse(); if(!course){box.innerHTML=''; return;}
  const av=selectedCourseAvailability();
  if(av.assigned>0 && av.available===0){ box.innerHTML=`<div class="alert alert-error">All chairs for this course/session are booked or blocked. <button class="btn-warn" onclick="joinWaitlist()">Join waiting list</button></div>`; }
  else box.innerHTML='';
}
function updateCurrentSelectionText(){ qs('currentSelectionText').textContent = `Date: ${appState.selectedDate} | Session: ${displaySession(appState.selectedSession)} | Course: ${courseLabel(selectedCourse())} | Selected chair: ${appState.selectedChairNumber ?? 'none'}`; }
function renderMyBookings(){
  const box=qs('myBookingBox'); const arr=myActiveBookings();
  if(!arr.length){ box.innerHTML='<h3>My active bookings</h3><p class="muted">No active bookings yet.</p>'; return; }
  box.innerHTML='<h3>My active bookings</h3>'+arr.map(b=>`<div class="course-card"><strong>Booking #${b.id}</strong> — Chair ${b.chairNumber}, ${b.date}, ${displaySession(b.session)}<br><span class="muted">${escapeHtml(b.courseCode)} · Patient: ${escapeHtml(b.patientName)}</span><div class="row" style="margin-top:8px"><button class="btn-light" onclick='showDetails(${JSON.stringify(b).replace(/'/g,"&#039;")})'>Details</button><button class="btn-danger" onclick="setStatus(${b.id}, 'cancelled')">Cancel booking</button></div></div>`).join('');
}
function showDetails(b){
  qs('detailsTitle').textContent = 'Booking details';
  const qrUrl = b.qrToken ? `${location.origin}${location.pathname}?qr=${encodeURIComponent(b.qrToken)}` : '';
  const qrImg = qrUrl ? `<div style="text-align:center;margin:12px 0"><img alt="QR confirmation" src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(qrUrl)}"><br><a target="_blank" href="${qrUrl}">Open QR confirmation</a></div>` : '';
  const html = `${qrImg}<p><strong>Booking ID:</strong> ${b.id}</p><p><strong>Chair:</strong> ${b.chairNumber}</p><p><strong>Date/session:</strong> ${escapeHtml(b.date)} · ${displaySession(b.session)}</p><p><strong>Course:</strong> ${escapeHtml(b.courseCode)} — ${escapeHtml(b.courseName)}</p><p><strong>Operator:</strong> ${escapeHtml(b.operatorName)}</p><p><strong>Assistant:</strong> ${escapeHtml(b.assistantName)}</p><p><strong>Patient:</strong> ${escapeHtml(b.patientName)}</p><p><strong>Patient phone:</strong> ${escapeHtml(b.patientPhone||'-')}</p><p><strong>Notes:</strong> ${escapeHtml(b.notes||'-')}</p><p><strong>AUIB entry permission needed:</strong> ${b.patientPermission ? 'Yes' : 'No'}</p><p><strong>Permission status:</strong> ${escapeHtml((b.permissionStatus||'not_needed').replaceAll('_',' '))}</p><p><strong>Check-in status:</strong> ${escapeHtml((b.checkInStatus||'not_checked').replaceAll('_',' '))}</p><p><strong>Supervisor:</strong> ${escapeHtml(b.supervisorName)}</p><p><strong>Booked by:</strong> ${escapeHtml(b.accountName)} ${b.universityId ? '('+escapeHtml(b.universityId)+')' : ''}</p><p><strong>Status:</strong> ${escapeHtml(b.status)}</p>`;
  qs('detailsContent').innerHTML=html; qs('detailsModal').classList.remove('hidden');
}
function showBlockedReason(chairNumber, blocked){
  qs('detailsTitle').textContent = 'Blocked chair';
  const reason = blocked.reason && blocked.reason.trim() ? blocked.reason : 'No reason written.';
  const html = `<p><strong>Chair:</strong> ${chairNumber}</p><p><strong>Date/session:</strong> ${escapeHtml(blocked.date)} · ${displaySession(blocked.session)}</p><p><strong>Status:</strong> Blocked</p><p><strong>Reason:</strong> ${escapeHtml(reason)}</p><p class="muted">This reason was written by a full-access or clinic management account.</p>`;
  qs('detailsContent').innerHTML=html; qs('detailsModal').classList.remove('hidden');
}
function renderManagement(){
  const u=appState.currentUser; if(!u) return;
  const canCourses=['owner','clinic_management'].includes(u.role); const canUsers=['owner','clinic_management'].includes(u.role);
  qs('userManagementCard').classList.toggle('hidden', !canUsers);
  qs('courseManagementCard').classList.toggle('hidden', !canCourses);
  qs('weeklySetupCard').classList.toggle('hidden', !canCourses);
  qs('approvedStudentsCard').classList.toggle('hidden', !canCourses);
  qs('settingsCard').classList.toggle('hidden', !canCourses);
  qs('backupBtn').classList.toggle('hidden', !canCourses);
  qs('managementTitle').textContent = u.role==='owner' ? 'Control panel' : (u.role==='clinic_management' ? 'Clinic management panel' : 'Doctor supervisor panel');
  qs('managementPanelSubtitle').textContent = u.role==='owner' ? 'Full access: booking, course management, chair assignment, user accounts, and supervisor controls.' : (u.role==='clinic_management' ? 'Clinic management can add courses, assign chairs, and create accounts.' : 'Doctor supervisors can see daily bookings and adjust them, but cannot create courses.');
  renderAdminChairChecks(); renderCourseAdmin(); renderUsersList(); renderApprovedStudents(); renderSettings(); renderAnalytics(); renderWeeklySchedule(); renderCapacity(); renderWaitingList(); renderBlockedChairs(); renderAdminFilters(); renderAdminBookings(); renderReports(); renderAudit();
}
function renderAdminChairChecks(){
  const selectedDate = qs('adminAssignmentDate') ? qs('adminAssignmentDate').value : appState.selectedDate;
  const selectedSession = qs('adminAssignmentSession') ? qs('adminAssignmentSession').value : appState.selectedSession;
  const selectedCourse = qs('adminAssignmentCourse') ? qs('adminAssignmentCourse').value : '';
  const existing = assignmentForCourse(selectedCourse, selectedDate, selectedSession);
  qs('adminChairChecks').innerHTML = appState.chairs.map(ch=>{
    const conflict = appState.assignments.find(a => a.date===selectedDate && a.session===selectedSession && String(a.courseId)!==String(selectedCourse) && a.chairs.includes(ch.number));
    const checked = existing && existing.chairs.includes(ch.number) ? 'checked' : '';
    const disabled = conflict ? 'disabled' : '';
    const note = conflict ? `<br><small>Used: ${escapeHtml(conflict.courseCode)}</small>` : '';
    return `<label class="check-card" style="${conflict?'opacity:.55':''}"><input type="checkbox" value="${ch.number}" ${checked} ${disabled}> ${ch.number}${note}</label>`;
  }).join('');
  const bc=qs('blockChair'); if(bc) bc.innerHTML=appState.chairs.map(ch=>`<option value="${ch.number}">Chair ${ch.number}</option>`).join('');
  const courseSelect=qs('adminAssignmentCourse'); if(courseSelect){ const current=courseSelect.value; courseSelect.innerHTML='<option value="">Choose course</option>'+appState.courses.filter(c=>c.active).map(c=>`<option value="${c.id}">${escapeHtml(courseLabel(c))}</option>`).join(''); if(appState.courses.some(c=>String(c.id)===String(current))) courseSelect.value=current; }
}
function renderCourseAdmin(){
  const box=qs('courseListBox');
  if(!appState.courses.length){ box.innerHTML='<p class="muted">No courses yet.</p>'; return; }
  const coursesHtml = '<h4>Courses</h4>' + appState.courses.map(c=>`<div class="course-card"><strong>${escapeHtml(c.code)}</strong> — ${escapeHtml(c.name)}<br><span class="muted">${c.active?'Active':'Inactive'}</span><div class="row" style="margin-top:8px"><button class="btn-danger" onclick="deleteCourse(${c.id})">Delete</button></div></div>`).join('');
  const assignmentsHtml = '<h4 style="margin-top:16px">Date/session chair assignments</h4>' + (appState.assignments.length ? appState.assignments.map(a=>`<div class="course-card"><strong>${escapeHtml(a.courseCode)}</strong> — ${escapeHtml(a.courseName)}<br><span class="muted">Date: ${escapeHtml(a.date)} · Session: ${displaySession(a.session)} · Chairs: ${a.chairs.join(', ')}</span><div class="row" style="margin-top:8px"><button class="btn-danger" onclick="deleteAssignmentGroup(${a.courseId}, '${a.date}', '${a.session}')">Remove assignment</button></div></div>`).join('') : '<p class="muted">No chair assignments yet.</p>');
  box.innerHTML = coursesHtml + assignmentsHtml;
}
function renderUsersList(){
  const box=qs('usersListBox'); if(!appState.users?.length){ box.innerHTML=''; return; }
  const canDelete = appState.currentUser && appState.currentUser.role === 'owner';
  const actionHead = '<th>Action</th>';
  box.innerHTML='<table><thead><tr><th>Name</th><th>ID/Login</th><th>Role</th>'+actionHead+'</tr></thead><tbody>'+appState.users.map(u=>{
    const reset = u.role !== 'owner' ? `<button class="btn-light" onclick="resetPassword(${u.id}, '${escapeJs(u.name)}')">Reset password</button>` : '';
    const del = canDelete && u.role !== 'owner' && Number(u.id) !== Number(appState.currentUser.id) ? `<button class="btn-danger" onclick="deleteUser(${u.id}, '${escapeJs(u.name)}')">Delete</button>` : (canDelete ? '<span class="muted">Protected</span>' : '');
    const action = `<td>${reset} ${del}</td>`;
    return `<tr><td>${escapeHtml(u.name)} ${u.must_change_password ? '<span class="badge badge-management">must change password</span>' : ''}</td><td>${escapeHtml(u.university_id||'')}</td><td>${roleLabel(u.role)}</td>${action}</tr>`;
  }).join('')+'</tbody></table>';
}
function renderApprovedStudents(){
  const box=qs('approvedStudentsBox'); if(!box) return;
  if(!(appState.approvedStudents||[]).length){ box.innerHTML='<p class="muted">No approved students yet. Students cannot register until they are added here.</p>'; return; }
  box.innerHTML='<table><thead><tr><th>ID</th><th>Name</th><th>Allowed</th><th>Action</th></tr></thead><tbody>'+appState.approvedStudents.map(s=>`<tr><td>${escapeHtml(s.universityId)}</td><td>${escapeHtml(s.name)}</td><td>${s.allowed?'Yes':'No'}</td><td><button class="btn-danger" onclick="deleteApprovedStudent(${s.id}, '${escapeJs(s.name)}')">Delete</button></td></tr>`).join('')+'</tbody></table>';
}
function renderSettings(){
  const st=appState.settings||{}; if(qs('bookingCloseHours')) qs('bookingCloseHours').value=st.booking_close_hours ?? 1; if(qs('cancelCloseHours')) qs('cancelCloseHours').value=st.cancel_close_hours ?? 2; if(qs('maintenanceMode')) qs('maintenanceMode').value=st.maintenance_mode?'1':'0'; if(qs('maintenanceReason')) qs('maintenanceReason').value=st.maintenance_reason || '';
  const box=qs('backupReminderBox'); if(!box) return; const last=st.last_backup_at; let msg='No database backup recorded yet.'; if(last){ const days=Math.floor((Date.now()-new Date(last.replace(' ','T')).getTime())/(1000*60*60*24)); msg=`Last backup: ${escapeHtml(last)} (${isNaN(days)?'?':days} days ago).`; }
  box.innerHTML=`<div class="alert ${last?'alert-success':'alert-error'}">${msg} <button class="btn-light" onclick="window.location='?api=backup_db'">Download backup now</button></div>`;
}
function renderAnalytics(){
  const a=appState.analytics||{}; const box=qs('analyticsBox'); if(!box) return;
  box.innerHTML=`<div class="stat-card"><strong>Total bookings this week</strong><h2>${a.totalWeek||0}</h2></div><div class="stat-card"><strong>Most used session</strong><h2>${escapeHtml(a.mostUsedSession||'-')}</h2></div><div class="stat-card"><strong>Most booked course</strong><h2>${escapeHtml(a.mostBookedCourse||'-')}</h2></div><div class="stat-card"><strong>Absent / Cancelled / Permission / Broken</strong><h3>${a.absentStudents||0} / ${a.cancelled||0} / ${a.permissionNeeded||0} / ${a.brokenChairs||0}</h3></div>`;
}
function renderWeeklySchedule(){
  const box=qs('weeklyScheduleBox'); if(!box) return; const rows=appState.weeklySchedule||[];
  box.innerHTML='<table><thead><tr><th>Day</th><th>Date</th><th>8:00</th><th>11:00</th><th>2:00</th></tr></thead><tbody>'+rows.map(r=>`<tr><td>${escapeHtml(r.day)}</td><td>${escapeHtml(r.date)}</td><td>${r['08:00']||0}</td><td>${r['11:00']||0}</td><td>${r['14:00']||0}</td></tr>`).join('')+'</tbody></table>';
}
function renderCapacity(){
  const box=qs('capacityBox'); if(!box) return; const rows=appState.capacity||[]; if(!rows.length){box.innerHTML='<p class="muted">No chair assignments yet.</p>';return;}
  box.innerHTML='<table><thead><tr><th>Course</th><th>Date</th><th>Session</th><th>Assigned</th><th>Booked</th><th>Remaining</th></tr></thead><tbody>'+rows.map(r=>`<tr><td>${escapeHtml(r.courseCode)}</td><td>${escapeHtml(r.date)}</td><td>${displaySession(r.session)}</td><td>${r.assigned}</td><td>${r.booked}</td><td>${r.remaining}</td></tr>`).join('')+'</tbody></table>';
}
function renderWaitingList(){
  const box=qs('waitingListBox'); if(!box) return; const rows=appState.waitingList||[]; if(!rows.length){box.innerHTML='<p class="muted">No waiting list requests.</p>';return;}
  box.innerHTML='<table><thead><tr><th>Student</th><th>Date</th><th>Session</th><th>Course</th><th>Status</th><th>Created</th></tr></thead><tbody>'+rows.map(w=>`<tr><td>${escapeHtml(w.studentName)}<br><span class="small muted">${escapeHtml(w.universityId||'')}</span></td><td>${escapeHtml(w.date)}</td><td>${displaySession(w.session)}</td><td>${escapeHtml(w.courseCode)}</td><td>${escapeHtml(w.status)}</td><td>${escapeHtml(w.createdAt)}</td></tr>`).join('')+'</tbody></table>';
}
function renderAdminFilters(){
  const sup=qs('adminFilterSupervisor'); if(sup){ const cur=sup.value; sup.innerHTML='<option value="all">All supervisors</option>'+appState.supervisors.map(s=>`<option value="${escapeHtml(s.name)}">${escapeHtml(s.name)}</option>`).join(''); sup.value=cur||'all'; }
  const co=qs('adminFilterCourse'); if(co){ const cur=co.value; co.innerHTML='<option value="all">All courses</option>'+appState.courses.map(c=>`<option value="${c.id}">${escapeHtml(c.code)}</option>`).join(''); co.value=cur||'all'; }
}
function renderBlockedChairs(){
  const box=qs('blockedChairsBox'); if(!box) return;
  const arr=appState.blocked || [];
  if(!arr.length){ box.innerHTML='<p class="muted">No blocked chairs.</p>'; return; }
  box.innerHTML='<table><thead><tr><th>Date</th><th>Session</th><th>Chair</th><th>Reason</th><th>Action</th></tr></thead><tbody>'+arr.map(b=>`<tr><td>${escapeHtml(b.date)}</td><td>${displaySession(b.session)}</td><td>${b.chairNumber}</td><td>${escapeHtml(b.reason||'')}</td><td><button class="btn-light" onclick="unblockChair(${b.id})">Unblock</button></td></tr>`).join('')+'</tbody></table>';
}
function renderReports(){
  const arr=adminFilteredBookings(); const active=arr.filter(b=>b.active); const permission=active.filter(b=>b.patientPermission); const excused=arr.filter(b=>b.status==='excused'); const cancelled=arr.filter(b=>b.status==='cancelled'); const attended=arr.filter(b=>b.status==='attended');
  qs('summaryBox').innerHTML = `<div class="stat-card"><strong>Total</strong><h2>${arr.length}</h2></div><div class="stat-card"><strong>Active</strong><h2>${active.length}</h2></div><div class="stat-card"><strong>Permission</strong><h2>${permission.length}</h2></div><div class="stat-card"><strong>Attended / Excused / Cancelled</strong><h3>${attended.length} / ${excused.length} / ${cancelled.length}</h3></div>`;
  qs('permissionListBox').innerHTML = permission.length ? '<h4>Patients needing AUIB entry permission</h4><table><thead><tr><th>Patient Name</th><th>Phone Number</th><th>Booking Date</th><th>Session Time</th></tr></thead><tbody>'+permission.map(b=>`<tr><td>${escapeHtml(b.patientName)}</td><td>${escapeHtml(b.patientPhone||'')}</td><td>${escapeHtml(b.date)}</td><td>${displaySession(b.session)}</td></tr>`).join('')+'</tbody></table>' : '<p class="muted">No permission requests for selected date/session.</p>';
}
function renderAudit(){
  const box=qs('auditBox'); if(!box) return;
  if(!appState.audit.length){ box.innerHTML='<p class="muted">No audit records yet.</p>'; return; }
  box.innerHTML='<table><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Booking</th><th>Details</th></tr></thead><tbody>'+appState.audit.slice(0,80).map(a=>`<tr><td>${escapeHtml(a.createdAt)}</td><td>${escapeHtml(a.actor)}</td><td>${escapeHtml(a.action)}</td><td>${escapeHtml(a.reservationId||'')}</td><td>${escapeHtml(a.details||'')}</td></tr>`).join('')+'</tbody></table>';
}
function adminFilteredBookings(){
  const d=qs('adminDate').value; const s=qs('adminSession').value;
  const sup=qs('adminFilterSupervisor')?.value || 'all'; const course=qs('adminFilterCourse')?.value || 'all'; const chair=(qs('adminFilterChair')?.value || '').trim(); const perm=qs('adminFilterPermission')?.value || 'all';
  return appState.bookings.filter(b => b.date===d && (s==='all' || b.session===s) && (sup==='all' || b.supervisorName===sup) && (course==='all' || String(b.courseId)===String(course)) && (!chair || String(b.chairNumber)===chair) && (perm==='all' || b.permissionStatus===perm || (perm==='needed' && b.patientPermission)));
}
function renderAdminBookings(){
  const body=qs('adminBookingsBody'); const arr=adminFilteredBookings();
  if(!arr.length){ body.innerHTML='<tr><td colspan="16" class="muted">No bookings for selected filters.</td></tr>'; return; }
  body.innerHTML = arr.map(b=>{
    const permSelect = `<select onchange="setPermissionStatus(${b.id}, this.value)"><option value="not_needed" ${b.permissionStatus==='not_needed'?'selected':''}>Not needed</option><option value="needed" ${b.permissionStatus==='needed'?'selected':''}>Permission needed</option><option value="sent_to_security" ${b.permissionStatus==='sent_to_security'?'selected':''}>Sent to security</option><option value="approved" ${b.permissionStatus==='approved'?'selected':''}>Approved</option><option value="rejected" ${b.permissionStatus==='rejected'?'selected':''}>Rejected</option></select>`;
    const actions = b.active ? `<button class="btn-light" onclick="setStatus(${b.id}, 'checked_in')">Check in</button> <button class="btn-light" onclick="setStatus(${b.id}, 'patient_arrived')">Patient arrived</button> <button class="btn-warn" onclick="setStatus(${b.id}, 'patient_did_not_arrive')">Patient did not arrive</button> <button class="btn-warn" onclick="setStatus(${b.id}, 'student_absent')">Student absent</button> <button class="btn-success" onclick="setStatus(${b.id}, 'case_completed')">Case completed</button> <button class="btn-danger" onclick="setStatus(${b.id}, 'cancelled')">Cancel</button> <button class="btn-warn" onclick="setStatus(${b.id}, 'excused')">Excuse</button>` : '<span class="muted">No active action</span>';
    return `<tr><td>${b.id}</td><td>${escapeHtml(b.date)}</td><td>${displaySession(b.session)}</td><td>${b.chairNumber}</td><td>${escapeHtml(b.courseCode)}</td><td>${escapeHtml(b.operatorName)}</td><td>${escapeHtml(b.assistantName)}</td><td>${escapeHtml(b.patientName)}</td><td>${escapeHtml(b.patientPhone||'')}</td><td>${b.patientPermission ? 'Yes' : 'No'}<br>${permSelect}</td><td>${escapeHtml(b.supervisorName)}</td><td>${escapeHtml(b.accountName)}<br><span class="small muted">${escapeHtml(b.universityId||'')}</span></td><td>${escapeHtml((b.checkInStatus||'not_checked').replaceAll('_',' '))}</td><td>${escapeHtml(b.status)}</td><td>${actions}</td></tr>`;
  }).join('');
}


let reportActionType = 'print_schedule';
function openReportModal(action){
  reportActionType = action;
  const labels = {
    print_schedule: 'Print clinic schedule',
    export_bookings: 'Export bookings CSV',
    export_permission: 'Export permission CSV'
  };
  qs('reportModalTitle').textContent = labels[action] || 'Choose report range';
  qs('reportDate').value = qs('adminDate').value || appState.selectedDate || appState.today || new Date().toISOString().slice(0,10);
  qs('reportModal').classList.remove('hidden');
}
function runReport(scope){
  const date = qs('reportDate').value || qs('adminDate').value || appState.selectedDate || new Date().toISOString().slice(0,10);
  const url = `?api=${encodeURIComponent(reportActionType)}&scope=${encodeURIComponent(scope)}&date=${encodeURIComponent(date)}`;
  qs('reportModal').classList.add('hidden');
  if(reportActionType === 'print_schedule'){
    const w = window.open(url, '_blank');
    if(!w) window.location = url;
  } else {
    window.location = url;
  }
}

async function register(){ const res=await api('register',{name:qs('regName').value, university_id:qs('regUniversityId').value, password:qs('regPassword').value}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function login(){ const res=await api('login',{name:qs('loginName').value, password:qs('loginPassword').value}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function logout(){ const res=await api('logout',{}); showAlert('success',res.message || 'Logged out.'); await loadState(); }
async function addCourse(){ const res=await api('create_course',{code:qs('adminCourseCode').value,name:qs('adminCourseName').value}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); qs('adminCourseCode').value=''; qs('adminCourseName').value=''; await loadState(); }
async function assignCourseChairs(){ const chairs=[...document.querySelectorAll('#adminChairChecks input:checked')].map(x=>Number(x.value)); const res=await api('assign_course_chairs',{courseId:Number(qs('adminAssignmentCourse').value),date:qs('adminAssignmentDate').value,session:qs('adminAssignmentSession').value,chairs}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function deleteAssignmentGroup(courseId,date,session){ if(prompt('Type DELETE to remove this chair assignment')!=='DELETE') return; const res=await api('delete_assignment_group',{courseId,date,session,confirm_text:'DELETE'}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function deleteCourse(id){ if(prompt('Type DELETE to confirm course deletion')!=='DELETE') return; const res=await api('delete_course',{id,confirm_text:'DELETE'}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function createUser(){ const res=await api('create_user',{name:qs('newUserName').value,university_id:qs('newUserId').value,role:qs('newUserRole').value,password:qs('newUserPassword').value}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); qs('newUserName').value=qs('newUserId').value=qs('newUserPassword').value=''; await loadState(); }
async function deleteUser(id,name){ if(prompt('Type DELETE to delete account for '+name) !== 'DELETE') return; const res=await api('delete_user',{id,confirm_text:'DELETE'}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function confirmBooking(){
  if(!selectedCourse()) return showAlert('error','Choose a course first.');
  if(!appState.selectedChairNumber) return showAlert('error','Choose a chair first.');
  const otherSessions=myActiveBookings().filter(b=>b.date===appState.selectedDate && b.session!==appState.selectedSession);
  if(otherSessions.length){ const labels=otherSessions.map(b=>displaySession(b.session)).join(', '); if(!confirm(`You already have a booking at ${labels}. Are you sure you want to book ${displaySession(appState.selectedSession)} too?`)) return; }
  const data={date:appState.selectedDate,session:appState.selectedSession,courseId:Number(appState.selectedCourseId),chairNumber:appState.selectedChairNumber,operatorName:qs('operatorName').value,assistantName:qs('assistantName').value,patientName:qs('patientName').value,patientPhone:qs('patientPhone').value,notes:qs('bookingNotes').value,supervisorName:qs('supervisorName').value,patientPermission:qs('patientPermission').checked?1:0};
  const res=await api('book',data); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); appState.selectedChairNumber=null; await loadState(); goBooking(false);
}

async function setStatus(id,status){ const res=await api('set_status',{id,status}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function switchBookings(){ const res=await api('switch',{a:Number(qs('switchA').value),b:Number(qs('switchB').value)}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function blockChair(){ const res=await api('block_chair',{date:qs('blockDate').value||qs('adminDate').value,session:qs('blockSession').value,chairNumber:Number(qs('blockChair').value),reason:qs('blockReason').value}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); qs('blockReason').value=''; await loadState(); }
async function unblockChair(id){ const res=await api('unblock_chair',{id}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function saveApprovedStudent(){ const res=await api('add_approved_student',{university_id:qs('approvedStudentId').value,name:qs('approvedStudentName').value,allowed:qs('approvedStudentAllowed').value==='1'}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); qs('approvedStudentId').value=''; qs('approvedStudentName').value=''; await loadState(); }
async function importApprovedStudents(){ const res=await api('import_approved_students',{text:qs('approvedBulkText').value}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); qs('approvedBulkText').value=''; await loadState(); }
async function deleteApprovedStudent(id,name){ if(prompt('Type DELETE to delete approved student '+name)!=='DELETE') return; const res=await api('delete_approved_student',{id,confirm_text:'DELETE'}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function saveSettings(){ const res=await api('update_settings',{booking_close_hours:qs('bookingCloseHours').value,cancel_close_hours:qs('cancelCloseHours').value,maintenance_mode:qs('maintenanceMode').value==='1',maintenance_reason:qs('maintenanceReason').value}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function copyLastWeek(){ if(!confirm('Copy last week chair assignments into this current week? Existing current assignments will not be overwritten.')) return; const res=await api('copy_last_week',{}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function importSetup(){ const res=await api('import_setup',{json:qs('setupImportText').value}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); qs('setupImportText').value=''; await loadState(); }
async function resetPassword(id,name){ const pw=prompt('Enter new temporary password for '+name); if(!pw) return; const res=await api('reset_password',{id,password:pw}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function changePassword(){ const pw=qs('forcedNewPassword').value; const res=await api('change_password',{password:pw}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); qs('forcedNewPassword').value=''; await loadState(); }
async function markNotificationsRead(){ const res=await api('mark_notifications_read',{}); if(!res.ok) return showAlert('error',res.message); await loadState(); }
async function setPermissionStatus(id,status){ const res=await api('set_permission_status',{id,status}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }
async function joinWaitlist(){ if(!selectedCourse()) return showAlert('error','Choose course first.'); const res=await api('join_waitlist',{date:appState.selectedDate,session:appState.selectedSession,courseId:Number(appState.selectedCourseId)}); if(!res.ok) return showAlert('error',res.message); showAlert('success',res.message); await loadState(); }

qs('tabRegister').onclick=()=>{ qs('tabRegister').classList.add('active'); qs('tabLogin').classList.remove('active'); qs('registerBox').classList.remove('hidden'); qs('loginBox').classList.add('hidden'); };
qs('tabLogin').onclick=()=>{ qs('tabLogin').classList.add('active'); qs('tabRegister').classList.remove('active'); qs('loginBox').classList.remove('hidden'); qs('registerBox').classList.add('hidden'); };
qs('registerBtn').onclick=register; qs('loginBtn').onclick=login; qs('changePasswordBtn').onclick=changePassword; qs('addCourseBtn').onclick=addCourse; qs('assignCourseChairsBtn').onclick=assignCourseChairs; qs('createUserBtn').onclick=createUser; qs('confirmBookingBtn').onclick=confirmBooking; qs('switchBtn').onclick=switchBookings; qs('refreshAdminBtn').onclick=()=>{renderAdminBookings();renderReports();}; qs('blockChairBtn').onclick=blockChair; qs('saveApprovedStudentBtn').onclick=saveApprovedStudent; qs('importApprovedStudentsBtn').onclick=importApprovedStudents; qs('saveSettingsBtn').onclick=saveSettings; qs('copyLastWeekBtn').onclick=copyLastWeek; qs('exportSetupBtn').onclick=()=>{window.location='?api=export_setup'}; qs('importSetupBtn').onclick=importSetup; qs('printBtn').onclick=()=>openReportModal('print_schedule'); qs('exportBookingsBtn').onclick=()=>openReportModal('export_bookings'); qs('exportPermissionBtn').onclick=()=>openReportModal('export_permission'); qs('backupBtn').onclick=()=>{window.location='?api=backup_db'}; qs('closeReportModalBtn').onclick=()=>qs('reportModal').classList.add('hidden'); qs('reportDateOnlyBtn').onclick=()=>runReport('date'); qs('reportWeekBtn').onclick=()=>runReport('week'); qs('reportFullBtn').onclick=()=>runReport('full');
qs('courseSelect').onchange=e=>{ appState.selectedCourseId=e.target.value; appState.selectedChairNumber=null; renderChairMap(); };
['adminAssignmentDate','adminAssignmentSession','adminAssignmentCourse'].forEach(id=>{ const el=qs(id); if(el) el.onchange=()=>renderAdminChairChecks(); });
qs('bookingDate').onchange=e=>{ appState.selectedDate=e.target.value; qs('adminDate').value=e.target.value; if(qs('adminAssignmentDate')) qs('adminAssignmentDate').value=e.target.value; appState.selectedCourseId=''; appState.selectedChairNumber=null; renderCourseSelect(); renderChairMap(); renderMyBookings(); };
qs('adminDate').onchange=()=>{renderAdminBookings();renderReports();}; qs('adminSession').onchange=()=>{renderAdminBookings();renderReports();}; ['adminFilterSupervisor','adminFilterCourse','adminFilterChair','adminFilterPermission'].forEach(id=>{ const el=qs(id); if(el) el.onchange=()=>{renderAdminBookings();renderReports();}; if(el && id==='adminFilterChair') el.oninput=()=>{renderAdminBookings();renderReports();}; });
qs('goToChairsBtn').onclick=()=>{ if(!selectedCourse()) return showAlert('error','Choose a course first.'); qs('chairSection').scrollIntoView({behavior:'smooth'}); };
qs('backToSessionsBtn').onclick=()=>qs('sessionSection').scrollIntoView({behavior:'smooth'});
qs('refreshChairsBtn').onclick=async()=>{ await loadState(); showAlert('success','Chair status refreshed.'); };
qs('closeDetailsBtn').onclick=()=>qs('detailsModal').classList.add('hidden');
document.querySelectorAll('.session-btn').forEach(btn=>btn.onclick=()=>{ appState.selectedSession=btn.dataset.session; appState.selectedCourseId=''; appState.selectedChairNumber=null; renderSessionButtons(); renderCourseSelect(); renderChairMap(); });
loadState();
// Automatic real-time polling was disabled because it made shared hosting slow.
// Use the "Refresh chairs" button on the booking screen for a lightweight manual refresh.
// This keeps the website fast on PHP/MySQL shared hosting and avoids repeated full-state reloads.
</script>

<div class="powered-watermark">Powered By : Mujahid Jabbar &amp; Dima Baraa</div>
</body>
</html>
