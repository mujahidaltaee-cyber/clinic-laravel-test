# AUIB Chair Booking System - Laravel 13 AwardSpace Test Package

This package is a Laravel 13 project that mounts the current tested PHP/MySQL booking engine inside Laravel so the UI and features remain the same while the project boots through Laravel.

## Important

This ZIP does **not** include the `vendor/` folder because Composer packages are too large to generate inside this chat. Laravel will not run without `vendor/`. You must create the `vendor/` folder once before uploading to AwardSpace.

Laravel 13 requires PHP 8.3 or newer. You said your AwardSpace PHP goes up to 8.5.6, so set PHP to 8.5 or 8.4 in AwardSpace first.

## Files that matter

- `composer.json` - requires Laravel 13
- `public/index.php` - Laravel public entry
- `legacy/clinic_engine.php` - the exact current booking system engine
- `legacy/data/db_config.php` - created automatically after MySQL setup
- `.htaccess` - redirects AwardSpace root to `/public`

## Step 1 - Build vendor folder in GitHub Codespaces

1. Create a temporary GitHub repo.
2. Upload this ZIP contents to the repo.
3. Open the repo in GitHub Codespaces.
4. In the terminal run:

```bash
composer install --no-dev --optimize-autoloader
cp .env.example .env
php artisan key:generate
php artisan optimize:clear
```

5. Make sure this file exists:

```text
vendor/autoload.php
```

6. Zip the whole project again **including** the `vendor` folder.

## Step 2 - Upload to AwardSpace

1. Open AwardSpace Control Panel.
2. Set PHP version to 8.4/8.5 if available.
3. Open File Manager.
4. Open your domain folder.
5. Delete the old site files if this is a clean Laravel test.
6. Upload the Laravel project contents so the folder looks like this:

```text
your-site-folder/
├── app/
├── bootstrap/
├── config/
├── legacy/
├── public/
├── routes/
├── storage/
├── vendor/
├── .env
├── .htaccess
├── artisan
└── composer.json
```

Do not upload it like this:

```text
your-site-folder/laravel13_clinic/app/...
```

The `.htaccess` file must be directly inside your site folder.

## Step 3 - Writable folders

Laravel needs these folders writable:

```text
storage/
bootstrap/cache/
legacy/data/
```

If AwardSpace File Manager has permissions, make them writable.

## Step 4 - MySQL setup

Open this private setup link:

```text
https://your-domain.atwebpages.com/?setup=MJ04Dima
```

Enter your AwardSpace MySQL details:

```text
Database Host: fdb1032.awardspace.net
Port: 3306
Database Name: your database name
Database Username: your database username
Database Password: your database password
```

After saving, normal users should open:

```text
https://your-domain.atwebpages.com
```

## Step 5 - If you get a 500 error

Temporarily edit `.env`:

```env
APP_DEBUG=true
```

Reload the website to see the real error. After fixing it, set it back:

```env
APP_DEBUG=false
```

Most common causes:

- `vendor/autoload.php` missing
- wrong PHP version
- storage or bootstrap/cache not writable
- bad `.htaccess`
- MySQL details are wrong

## Note about this Laravel build

This is the AwardSpace-testable Laravel conversion package. It preserves the exact currently tested website by mounting the existing engine inside Laravel. A full MVC Laravel rebuild with separate models, migrations, controllers, policies, and Blade components is the next production refactor step after the workflow is finalized.
