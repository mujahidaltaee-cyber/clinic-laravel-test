<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('clinic:info', function () {
    $this->info('AUIB Chair Booking System - Laravel 13 wrapper is installed.');
});
