<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LegacyClinicController;

Route::any('/{any?}', [LegacyClinicController::class, 'handle'])
    ->where('any', '.*')
    ->name('clinic');
